import {
  saveSession,
  loadSession,
  listSessions,
  deleteSession,
  isBase64DataURL,
  isValidBase64Image,
  deleteAllSessionsWithMedia,
  getMediaStats,
} from './lib/indexedDBUtil.mjs';

import {
  validateApiKey,
  getKeyUsageStats,
  startRecordingSession,
  startAnnotationSession,
  completeAnnotationSession,
  completeRecordingSession,
  uploadSessionMedia,
  getProcessResult,
} from './api.js';



function createNotification(sessionId) {
  const notificationId = `promptReady|${sessionId}`;

  chrome.notifications.create(notificationId, {
    type: 'basic',
    iconUrl: '/icons/icon16.png',
    title: 'Prompt Ready',
    message: 'Click to view your prompt.',
    priority: 2,
  });
}


async function getSessionState(tabId) {
  const { activeSessions = {} } = await chrome.storage.local.get(
    'activeSessions'
  );
  return activeSessions[tabId] || null;
}

async function setSessionState(tabId, sessionId) {
  const { activeSessions = {} } = await chrome.storage.local.get(
    'activeSessions'
  );
  activeSessions[tabId] = { sessionId, isRecording: true };
  await chrome.storage.local.set({ activeSessions });
}

async function clearSessionState(tabId) {
  const { activeSessions = {} } = await chrome.storage.local.get(
    'activeSessions'
  );
  delete activeSessions[tabId];
  await chrome.storage.local.set({ activeSessions });
}

async function getAllActiveSessions() {
  const { activeSessions = {} } = await chrome.storage.local.get(
    'activeSessions'
  );
  return activeSessions;
}

function generateFallbackSessionId() {
  const now = Date.now();
  const timeHex = now.toString(16).padStart(12, '0');

  let i = 0;
  const template = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx';

  return template.replace(/[xy]/g, function (c) {
    let r;
    if (i < timeHex.length) {
      r = parseInt(timeHex[i], 16);
    } else {
      r = (Math.random() * 16) | 0;
    }

    const v = c === 'x' ? r : (r & 0x3) | 0x8;
    i++;
    return v.toString(16);
  });
}

async function wasApiDownFor(sessionId) {
  const stored = await chrome.storage.local.get(sessionId);
  return !!stored[sessionId]?.apiDown;
}

async function uploadAllMedia(sessionId, media) {
  const uploadTasks = [];

  if (isBase64DataURL(media.audio)) {
    uploadTasks.push(
      uploadSessionMedia({
        base64Data: media.audio,
        mediaType: 'audio',
        sessionId,
        fileType: media.audioType || 'audio/webm',
        fileName: 'recording.webm',
      })
    );
  }

  if (isValidBase64Image(media.screenshot)) {
    uploadTasks.push(
      uploadSessionMedia({
        base64Data: media.screenshot,
        mediaType: 'screenshot',
        sessionId,
        fileType: media.screenshotType || 'image/png',
        fileName: 'screenshot.png',
      })
    );
  }

  if (isValidBase64Image(media.annotation)) {
    uploadTasks.push(
      uploadSessionMedia({
        base64Data: media.annotation,
        mediaType: 'annotation',
        sessionId,
        fileType: media.annotationType || 'image/png',
        fileName: 'annotation.png',
      })
    );
  }

  await Promise.all(uploadTasks);
}

const heartbeatIntervals = new Map();

function startHeartbeat(tabId, sessionId) {
  stopHeartbeat(tabId);

  const intervalId = setInterval(() => {
    chrome.tabs.sendMessage(
      tabId,
      {
        type: 'heartbeat',
        recordingSessionId: sessionId,
      },
      (response) => {
        if (chrome.runtime.lastError || !response?.alive) {
          console.warn(
            `[Heartbeat] Session lost on tab ${tabId}. Cleaning up...`
          );
          cleanupRecording(tabId);
        }
      }
    );
  }, 1000);

  heartbeatIntervals.set(tabId, intervalId);
}

function stopHeartbeat(tabId) {
  const intervalId = heartbeatIntervals.get(tabId);
  if (intervalId) {
    clearInterval(intervalId);
    heartbeatIntervals.delete(tabId);
  }
}

async function cleanupRecording(tabId) {
  await clearSessionState(tabId);
  stopHeartbeat(tabId);

  const activeSessions = await getAllActiveSessions();
  const stillActive = Object.values(activeSessions).some((s) => s?.isRecording);

  if (!stillActive) {
    await chrome.storage.local.set({ isRecording: false });
  }
}

chrome.runtime.onInstalled.addListener((details) => {
  chrome.storage.local.set({ isRecording: false });
  chrome.storage.local.remove('activeSessions');

  checkAndProcessSessions();
  chrome.alarms.create('processSessions', { periodInMinutes: 0.5 });
  
  if (details.reason === 'install') {

    
    chrome.storage.local.set({
      sessions: [],
      settings: {
        theme: 'light',
        promptHistoryLimit: 50,
      },
    });

    if (chrome.sidePanel) {
      chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: false });

      chrome.sidePanel.setOptions({
        enabled: true,
        path: 'index.html?context=sidePanel',
      });
    }
  } else if (details.reason === 'update') {
  }
});

function isInjectableUrl(url) {
  return (
    typeof url === 'string' &&
    url.trim() !== '' &&
    !url.startsWith('chrome://') &&
    !url.startsWith('chrome-extension://') &&
    !url.startsWith('devtools://') &&
    !url.startsWith('about:') &&
    !url.startsWith('view-source:')
  );
}

function sendMessageToTab(tabId, message) {
  return new Promise((resolve, reject) => {
    chrome.tabs.sendMessage(tabId, message, (response) => {
      if (chrome.runtime.lastError) {
        reject(new Error(chrome.runtime.lastError.message));
      } else {
        resolve(response);
      }
    });
  });
}

chrome.runtime.onConnect.addListener(function (port) {
  if (port.name === 'SidePanel_FP') {
    port.onDisconnect.addListener(async () => {
      chrome.storage.local.set({ sidePanelOpened: false });
    });
  }
});

async function isContentScriptValid(tabId) {
  try {
    await sendMessageToTab(tabId, { action: 'ping' });
    return true;
  } catch (err) {
    console.warn(err)
    return false;
  }
}

async function handleStartRecording(message, sendResponse) {
  try {
    const tabId = message.tabId;
    const tabUrl = message.tabURL;
    if (!isInjectableUrl(tabUrl)) {
      throw new Error(`Cannot inject into restricted URL: ${tabUrl}`);
    }

    const allSessions = await getAllActiveSessions();

    let sessionFound = false;

    for (const [otherTabIdStr, session] of Object.entries(allSessions)) {
      const otherTabId = parseInt(otherTabIdStr, 10);
      if (otherTabId !== tabId && session?.isRecording) {
        console.warn(
          `[Session Switch] Cancelling previous session in tab ${otherTabId}`
        );
        chrome.tabs.sendMessage(otherTabId, { type: 'CANCEL_VIA_BACKGROUND' });
        await clearSessionState(otherTabId);
        stopHeartbeat(otherTabId);
        sessionFound = true;
      }
    }

    if (!sessionFound) {
      await chrome.storage.local.set({ isRecording: false });
    }
    const scriptIsValid = await isContentScriptValid(tabId);
    if (!scriptIsValid) {
      await clearSessionState(tabId);
      await chrome.storage.local.set({ isRecording: false });
      sendResponse({
        success: false,
        error: 'Extension context invalidated — Please reload the tab and try again...',
      });
      return;
    }

    const response = await sendMessageToTab(
      tabId,
      {
        action: 'startRecording',
        options: {
          annotateOnly: message.annotateOnly || false,
        },
      },
      tabUrl
    );

    if (!response?.recordingSessionId) {
      throw new Error('An error occured please try again later.');
    }
    await setSessionState(tabId, response.recordingSessionId);
    startHeartbeat(tabId, response.recordingSessionId);
    chrome.runtime.sendMessage({ type: 'CLOSE_POPUP' }, () => {
      console.log('Popup closed');
    });
    sendResponse({ success: true });
  } catch (error) {
    console.warn('[Start Recording] Failed:', error.message);
    await chrome.storage.local.set({ isRecording: false });
    sendResponse({ success: false, error: error.message });
  }
}

async function handleRecordingStarted(message, sender, sendResponse) {
  const tabId = sender.tab?.id;
  const sessionId = message.sessionId;

  if (!tabId || !sessionId) {
    console.warn('Missing tab ID or session ID in RECORDING_STARTED');
    sendResponse({ status: 'ignored' });
    return;
  }


  const sessions = await getAllActiveSessions();
  const activeSession = sessions[tabId];
  console.log(activeSession, sessionId)
  if (activeSession?.sessionId === sessionId) {
    await chrome.storage.local.set({ isRecording: true });
    console.log("Was a valid session");
    sendResponse({ status: 'ok' });
  } else {
    console.warn(`Session mismatch: tabId=${tabId}, sessionId=${sessionId}`);
    sendResponse({ status: 'mismatch' });
  }
}

async function handleClearSessions(sendResponse) {
  try {
    await deleteAllSessionsWithMedia();
    sendResponse({ success: true });
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

async function handleValidateLicenseKey(message, sendResponse) {
  try {
    const res = await validateApiKey(message.licenseKey);
    sendResponse(res);
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

async function handleGetKeyUsageStats(sendResponse) {
  try {
    const res = await getKeyUsageStats();
    sendResponse(res);
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

async function handleGetLocalStats(sendResponse) {
  try {
    const res = await getMediaStats();
    sendResponse(res);
  } catch (err) {
    sendResponse({ success: false, error: err.message });
  }
}

function handleRecordingCancelled(sender, sendResponse) {
  const tabId = sender.tab?.id;
  cleanupRecording(tabId);
  sendResponse({ success: true, message: 'Session cancelled.' });
}

function handleTakeScreenshot(sender, sendResponse) {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (!tab || !sender.tab || tab.id !== sender.tab.id) {
      sendResponse({ success: false, error: 'Sender is not the active tab' });
      return;
    }

    chrome.tabs.captureVisibleTab(
      chrome.windows.WINDOW_ID_CURRENT,
      { format: 'png' },
      (dataUrl) => sendResponse({ success: true, screenshot: dataUrl })
    );
  });
}


async function handleSaveSession(message, sender, sendResponse) {
  const tabId = sender.tab?.id;
  await chrome.storage.local.set({ isRecording: false });

  try {
    const { metadata, media } = message.data;
    const sessionId = message.ID;

    const sessionState = await getSessionState(tabId);
    const isCurrentSession = sessionState?.sessionId === sessionId;

    const { user_identifer } = await chrome.storage.local.get('user_identifer');
    const userAgent = navigator.userAgent;

    const isAnnotationOnly = metadata?.isAnnotationOnly;

    const sessionRes = await fetchWithRetry(() =>
      isAnnotationOnly
        ? startAnnotationSession(user_identifer, userAgent)
        : startRecordingSession(user_identifer, userAgent)
    );

    if (!sessionRes.success) throw new Error('Failed to start session. Please try again later.');

    const newSessionId = sessionRes.sessionId;
    await saveSession(newSessionId, metadata, media);

    if (isCurrentSession) {
      await setSessionState(tabId, newSessionId);
      await clearSessionState(tabId);
      stopHeartbeat(tabId);
    }
    if(!isAnnotationOnly)
      await uploadAllMedia(newSessionId, media);

    const completeRes = await fetchWithRetry(() =>
      isAnnotationOnly
        ? completeAnnotationSession(newSessionId)
        : completeRecordingSession(newSessionId)
    );

    if (!completeRes.success) throw new Error(completeRes.error);

    sendMessage({ type: 'UPDATE_SESSIONS' });
    checkAndProcessSessions();
    sendResponse({ success: true });

  } catch (error) {
    console.warn('Error saving session:', error);
    sendResponse({ success: false, error: error.message });
  }
}


async function handleLoadSession(message, sendResponse) {
  const sessionId = message.sessionId;
  const result = await getSessionDetails(sessionId);

  if (result.success) {
    sendResponse({ success: true, sessionData: result.sessionData });
  } else {
    sendResponse({
      success: false,
      error: result.error || 'Unknown error loading session',
    });
  }
}

async function handleListSessions(sendResponse) {
  try {
    const sessions = await listSessions();

    const enhancedSessions = sessions.map((session) => {
      const enhancedSession = { ...session };

      if (session.media) {
        enhancedSession.hasAudio = !!session.media.audio;
        enhancedSession.hasScreenshot = !!session.media.screenshot;
        enhancedSession.hasAnnotation = !!session.media.annotation;
      }

      if (
        session.formattedDuration &&
        session.formattedDuration !== 'Infinity:NaN'
      ) {
        enhancedSession.duration = session.formattedDuration;
      } else if (typeof session.duration === 'number' && session.duration > 0) {
        const minutes = Math.floor(session.duration / 60);
        const seconds = Math.floor(session.duration % 60);
        enhancedSession.duration = `${minutes}:${
          seconds < 10 ? '0' : ''
        }${seconds}`;
      } else {
        enhancedSession.duration = '0:00';
      }

      enhancedSession.formattedDuration = enhancedSession.duration;
      return enhancedSession;
    });

    sendResponse({ success: true, sessions: enhancedSessions });
  } catch (error) {
    console.error('Error listing sessions:', error);
    sendResponse({ success: false, error: error.message || 'Unknown error' });
  }
}

function handleOpenSidePanelMessage(sendResponse) {
  try {
    handleOpenSidePanel();
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: error.message });
  }
}

function handleOpenSidePanel() {
  chrome.sidePanel.open({ windowId: chrome.windows.WINDOW_ID_CURRENT });
}

function handleOpenPopup(sendResponse) {
  chrome.windows.getLastFocused({}, (window) => {
    chrome.windows.update(window.id, { focused: true }, () => {
      try {
        chrome.action.openPopup({ windowId: window.id });
        sendResponse({ success: true });
      } catch (error) {
        sendResponse({ success: false, error: error.message });
      }
    });
  });

  return true;
}

chrome.notifications.onClicked.addListener((notificationId) => {
  const [prefix, sessionId] = notificationId.split('|');

  if (prefix === 'promptReady') {
    chrome.sidePanel.setOptions({
      path: `index.html?context=sidePanel&sessionId=${sessionId}`,
      enabled: true,
    });

    chrome.windows.getCurrent({}, (window) => {
      chrome.sidePanel.open({ windowId: window.id });
    });
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handlers = {
    RECORDING_STARTED: () => handleRecordingStarted(message, sender, sendResponse) ,
    CLEAR_SESSIONS: () => handleClearSessions(sendResponse),
    validateLicenseKey: () => handleValidateLicenseKey(message, sendResponse),
    getKeyUsageStats: () => handleGetKeyUsageStats(sendResponse),
    GET_LOCAL_STATS: () => handleGetLocalStats(sendResponse),
    RECORDING_CANCELLED: () => handleRecordingCancelled(sender, sendResponse),
    START_RECORDING: () => handleStartRecording(message, sendResponse),
    TAKE_SCREENSHOT: () => handleTakeScreenshot(sender, sendResponse),
    SAVE_SESSION: () => handleSaveSession(message, sender, sendResponse),
    LOAD_SESSION: () => handleLoadSession(message, sendResponse),
    LIST_SESSIONS: () => handleListSessions(sendResponse),
    OPEN_POPUP: () => handleOpenPopup(sendResponse),
    OPEN_SIDEPANELX: () => handleOpenSidePanelMessage(sendResponse),
  };

  if (handlers[message.type]) {
    handlers[message.type]();
    return true;
  }
});

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'OPEN_SIDEPANEL') {
    console.log(message.payload);
    const targetTab =
      message.payload?.targetTab === 'history' ? 'history' : 'home';

    const panelUrl = `index.html?context=sidePanel&tab=${targetTab}`;

    chrome.sidePanel.setOptions(
      {
        path: panelUrl,
        enabled: true,
      },
      () => {
        // Don't open here unless called from user gesture
        sendResponse({ success: true });
      }
    );

    return true;
  }
});

async function savePendingSessions(sessionId) {
  const { user_identifer } = await chrome.storage.local.get('user_identifer');
  const userAgent = navigator.userAgent;

  try {
    const res = await startRecordingSession(user_identifer, userAgent);
    if (!res.success) {
      console.warn(`API still down for ${sessionId}`);
      return null;
    }

    const newSessionId = res.sessionId;

    const details = await getSessionDetails(sessionId);
    if (!details.success || !details.sessionData) return null;

    const { sessionData } = details;
    const media = {
      audio: sessionData.audioUrl,
      screenshot: sessionData.screenshotUrl,
      annotation: sessionData.annotationUrl,
      audioType: sessionData.metadata?.audioType,
      screenshotType: sessionData.metadata?.screenshotType,
      annotationType: sessionData.metadata?.annotationType,
      audioSize: sessionData.audioSize,
      screenshotSize: sessionData.screenshotSize,
      annotationSize: sessionData.annotationSize,
    };

    await uploadAllMedia(newSessionId, media);
    await saveSession(newSessionId, sessionData.metadata, media);
    await completeRecordingSession(newSessionId);

    await chrome.storage.local.remove(sessionId);
    await deleteSession(sessionId);
    sendMessage({ type: 'UPDATE_SESSIONS' });

    return {
      sessionId: newSessionId,
      sessionItem: { ...sessionData, isSession: true },
    };
  } catch (error) {
    console.error(`Error Retrying ${sessionId}:`, error);
    return null;
  }
}

async function processSession(sessionId, sessionItem = null) {
  try {
    const item =
      sessionItem || (await chrome.storage.local.get(sessionId))[sessionId];
    const data = await getProcessResult(sessionId);

    if (data?.success && data?.finalPrompt) {
      const updatedSession = {
        ...item,
        content: data.finalPrompt,
        processed: true,
      };

      await chrome.storage.local.set({ [sessionId]: updatedSession });
      sendMessage({ type: 'UPDATE_SESSIONS' });
      createNotification(sessionId);
      console.log(`[✅ Processed] ${sessionId}`);
      
    } else {
      console.warn(`[⚠️ Skipped] ${sessionId}: No final prompt`, data);
    }
  } catch (error) {
    console.error(`[❌ Error Processing] ${sessionId}:`, error);
  }
}

async function checkAndProcessSessions() {
  chrome.storage.local.get(null, async (storage) => {
    const pendingSaves = [];
    const processables = [];

    for (const key in storage) {
      const item = storage[key];
      if (!item?.isSession || item.processed || (item.isAnnotationOnly)) continue;

      if (await wasApiDownFor(key)) {
        pendingSaves.push(
          savePendingSessions(key).then((res) => {
            if (res?.sessionId) {
              return processSession(res.sessionId, res.sessionItem);
            }
          })
        );
      } else {
        processables.push(processSession(key, item));
      }
    }
    await Promise.all([...pendingSaves, ...processables]);
  });
}

async function getSessionDetails(sessionId) {
  try {
    if (!sessionId) throw new Error('No session ID provided');

    const sessionData = await loadSession(sessionId);
    if (!sessionData) throw new Error('Session not found');

    const responseData = {
      id: sessionId,
      metadata: sessionData.metadata || null,
    };

    if (sessionData.media) {
      try {
        const hasValidAudio = isBase64DataURL(sessionData.media.audio);
        const hasValidScreenshot = isBase64DataURL(
          sessionData.media.screenshot
        );
        const hasValidAnnotation = isBase64DataURL(
          sessionData.media.annotation
        );

        if (hasValidAudio) {
          responseData.audioUrl = sessionData.media.audio;
          responseData.audioSize = sessionData.media.audioSize;
          responseData.hasAudio = true;
        }

        if (hasValidScreenshot) {
          responseData.screenshotUrl = sessionData.media.screenshot;
          responseData.screenshotSize = sessionData.media.screenshotSize;
          responseData.hasScreenshot = true;
        }

        if (hasValidAnnotation) {
          responseData.annotationUrl = sessionData.media.annotation;
          responseData.annotationSize = sessionData.media.annotationSize;
          responseData.hasAnnotation = true;
        }
      } catch (mediaErr) {
        console.error(`[Media Error] ${sessionId}:`, mediaErr);
        responseData.mediaError = mediaErr.message;
      }
    } else {
      responseData.mediaError = 'No media found';
    }

    if (responseData.metadata) {
      responseData.metadata.hasAudio = !!responseData.audioUrl;
      responseData.metadata.hasScreenshot = !!responseData.screenshotUrl;
      responseData.metadata.hasAnnotation = !!responseData.annotationUrl;
      responseData.metadata.mediaTypes = [
        responseData.audioUrl ? 'audio' : null,
        responseData.screenshotUrl ? 'screenshot' : null,
        responseData.annotationUrl ? 'annotation' : null,
      ].filter(Boolean);
    }

    return { success: true, sessionData: responseData };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

const fetchWithRetry = async (fn, retries = 2, delay = 500) => {
  for (let i = 0; i < retries; i++) {
    try {
      return await fn();
    } catch (err) {
      if (i === retries - 1) throw err;
      await new Promise((res) => setTimeout(res, delay));
    }
  }
};

function sendMessage(message) {
  try {
    chrome.runtime.sendMessage(message, () => {
      if (chrome.runtime.lastError) {
      }
    });
  } catch (err) {}
}

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === 'processSessions') {
    checkAndProcessSessions();
  }
});


