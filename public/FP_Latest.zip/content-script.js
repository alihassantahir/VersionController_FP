







/**
 * Chrome Extension Content Script
 *
 * This script is injected into web pages to create the floating widget
 * and handle interactions with it. It communicates with the background script
 * to open the sidebar when clicked.
 */


let activeRecordingSessionId = null;

// Handle messages from the background script
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
 // console.log("Content script received message:", message);

if (message.action === 'ping') {
  const domReady = ['complete', 'interactive'].includes(document.readyState);

  if (!domReady) {
    sendResponse({ pageLoaded: false });
    return;
  }

  if (window.self === window.top) {
    sendResponse({ pageLoaded: true, pong: true });
  } else {
    sendResponse({ pageLoaded: true, pong: false });
  }
  return;
}

  if (message.action === 'showWidget') {
    console.log('Show widget message received');
    createWidget();
    sendResponse({ success: true });
    return true;
  }

  if (message.action === 'hideWidget') {
    console.log('Hide widget message received');
    hideWidget();
    sendResponse({ success: true });
    return true;
  }

  if (message.action === 'startRecording') {
    try {
       
      const recordingSessionId = generateUUID();
      activeRecordingSessionId = recordingSessionId;

      const result = startRecording(
        message.options.annotateOnly || false,
        recordingSessionId
      );

      sendResponse({
        ...result,
        success: true,
        recordingSessionId,
      });
    } catch (error) {
      console.error('Error starting recording:', error);
      sendResponse({
        success: false,
        error: error.message || 'Unknown error starting recording',
      });
    }
    return true;
  }

  if (message.type === 'heartbeat') {
    if (
      activeRecordingSessionId &&
      activeRecordingSessionId === message.recordingSessionId
    ) {
      sendResponse({ alive: true });
    } else {
      sendResponse({ alive: false });
    }
    return true;
  }

  // Return true to indicate async response
  return true;
});

function generateUUID() {
  const arr = new Uint8Array(16);
  crypto.getRandomValues(arr);

  // Set version (4) and variant (10)
  arr[6] = (arr[6] & 0x0f) | 0x40; // version 4
  arr[8] = (arr[8] & 0x3f) | 0x80; // variant 10

  return [...arr].map((b, i) =>
    [4, 6, 8, 10].includes(i) ? '-' + b.toString(16).padStart(2, '0')
                              : b.toString(16).padStart(2, '0')
  ).join('');
}


// Flag to track if the widget is currently shown
let widgetVisible = false;

// Debug: Verify content script loads
console.log('AI Prompt Builder Content Script Loaded');

// Reference to the widget element
let widget = null;

// Flag to track recording mode (full recording vs annotation only)
let isAnnotateOnlyMode = false;

// Variables to track recording UI state
let recordingOverlayActive = false;
let countdownActive = false;
let recordingSidebarActive = false;
let countdownElement = null;
let recordingSidebarElement = null;
let hasAudioPermission = false;

// Audio recording variables
let audioStream = null;
let mediaRecorder = null;
let audioChunks = [];
let isRecording = false;
let recordingStartTime = 0;
let recordingDuration = 0;
let recordingTimer = null;
let audioVisualizationData = Array(8).fill(0);
let audioContext = null;
let audioAnalyser = null;
let audioVisualizationAnimationFrame = null;

// Screenshot and scroll tracking variables
let scrollFootprintTracker = null;
let capturedScreenshots = {};
// Annotation variables
let isAnnotationActive = false;
let annotationTool = 'pen';
let annotationColor = '#ff0000';
let annotationLineWidth = 3;
let selectedColor = '#ff0000';

// Screenshot blob management
let screenshotBlob = null;
let manualScreenshotTaken = false;
let annotationCanvasElement = null;
let selectedElementId = null;
let mouseDownPos = null;

// Debug flag - to help troubleshoot UI consistency issues
let debugMode = true;

// Global references to annotation UI elements (set when recording sidebar is created)
let annotationTools = null;
let drawingToolButton = null;



// Function to update annotation UI - moved early to prevent ReferenceError
function updateAnnotationUI() {
  console.log(
    'updateAnnotationUI called, isAnnotationActive:',
    isAnnotationActive
  );
  console.log('annotationTools exists:', !!annotationTools);
  console.log('drawingToolButton exists:', !!drawingToolButton);

  // Check if the required DOM elements exist before trying to use them
  if (!annotationTools || !drawingToolButton) {
    console.log('Annotation UI elements not ready yet');
    return;
  }

  console.log(
    'About to update annotation UI, current display:',
    annotationTools.style.display
  );

  if (isAnnotationActive) {
    annotationTools.style.display = 'flex';
    console.log('Set annotationTools display to flex');

    // Change drawing tool button background to purple to indicate selection
    drawingToolButton.style.backgroundColor = '#5845FF'; // Purple background
    drawingToolButton.style.color = 'white'; // White icon for better contrast

    // Add green checkmark indicator to drawing tool button
    const checkmark = document.createElement('div');
    checkmark.style.position = 'absolute';
    checkmark.style.marginLeft = '40px';
    checkmark.style.marginTop = '-25px';
    checkmark.style.width = '16px';
    checkmark.style.height = '16px';
    checkmark.style.borderRadius = '50%';
    checkmark.style.backgroundColor = '#10b981';
    checkmark.style.display = 'flex';
    checkmark.style.alignItems = 'center';
    checkmark.style.justifyContent = 'center';
    checkmark.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="white" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <polyline points="20 6 9 17 4 12"></polyline>
    </svg>`;

    // Add checkmark if not already present
    if (!drawingToolButton.querySelector('.checkmark-indicator')) {
      checkmark.className = 'checkmark-indicator';
      drawingToolButton.appendChild(checkmark);
    }
  } else {
    annotationTools.style.display = 'none';
    // Reset the button style when not active
    drawingToolButton.style.backgroundColor = 'white';
    drawingToolButton.style.color = 'currentColor'; // Reset to default color

    // Remove checkmark if exists
    const checkmark = drawingToolButton.querySelector('.checkmark-indicator');
    if (checkmark && document.body.contains(checkmark)) {
      drawingToolButton.removeChild(checkmark);
    }
  }
}

function resetAnnotationDrawingState() {
  if (!annotationCanvasElement) return;

  annotationCanvasElement.isDrawing = false;
  annotationCanvasElement.currentLine = null;
  annotationCanvasElement.currentShape = null;
  annotationCanvasElement.mouseDownPos = null;
  annotationCanvasElement.startPos = null;

  // Clear transformer selection
  annotationCanvasElement.selectedId = null;
  annotationCanvasElement.transformer.nodes([]);
}

/**
 * Activate annotation canvas overlay
 */
function activateAnnotationCanvas() {
  if (annotationCanvasElement) {
    // Already active
    return;
  }

  // Note: Viewport screenshot will be captured at save time when annotations are complete

  // Disable page scrolling when annotation mode is active
  document.body.style.overflow = 'hidden';
  document.documentElement.style.overflow = 'hidden';

  // Create annotation canvas container
  const canvasContainer = document.createElement('div');
  canvasContainer.id = 'annotation-canvas-container';
  canvasContainer.style.position = 'fixed';
  canvasContainer.style.top = '0';
  canvasContainer.style.left = '0';
  canvasContainer.style.width = '100vw';
  canvasContainer.style.height = '100vh';
  canvasContainer.style.zIndex = '9999';
  canvasContainer.style.pointerEvents = 'auto';

  // Create the Konva stage for drawing
  const stage = new Konva.Stage({
    container: canvasContainer,
    width: window.innerWidth,
    height: window.innerHeight,
  });

  const layer = new Konva.Layer();
  stage.add(layer);

  // Add transformer layer for selection
  const transformerLayer = new Konva.Layer();
  const transformer = new Konva.Transformer({
    boundBoxFunc: function (oldBox, newBox) {
      // Prevent scaling too small
      if (newBox.width < 5 || newBox.height < 5) {
        return oldBox;
      }
      return newBox;
    },
  });
  transformerLayer.add(transformer);
  stage.add(transformerLayer);

  // Store references
  annotationCanvasElement = {
    container: canvasContainer,
    stage: stage,
    layer: layer,
    transformerLayer: transformerLayer,
    transformer: transformer,
    shapes: [],
    lines: [],
    isDrawing: false,
    currentLine: null,
    selectedId: null,
    mouseDownPos: null,
  };

  // Add mouse/touch events for drawing
  stage.on('mousedown touchstart', handleAnnotationMouseDown);
  stage.on('mousemove touchmove', handleAnnotationMouseMove);
  stage.on('mouseup touchend', handleAnnotationMouseUp);

  // Add keyboard shortcuts
  document.addEventListener('keydown', handleAnnotationKeyDown);

  // Add window resize handler
  window.addEventListener('resize', handleAnnotationWindowResize);

  // Prevent page scrolling during annotation
  document.body.style.overflow = 'hidden';

  // Add exit banner
  const exitBanner = document.createElement('div');
  exitBanner.className = '__injected_exit_banner__';
  exitBanner.innerHTML = 'Press ESC or click here to exit annotation mode ×';
  exitBanner.onclick = deactivateAnnotationCanvas;

  canvasContainer.appendChild(exitBanner);
  document.body.appendChild(canvasContainer);
}

/**
 * Deactivate annotation canvas overlay
 */
function deactivateAnnotationCanvas() {
  if (!annotationCanvasElement) {
    return;
  }

  // Save annotation if there's content
  if (
    annotationCanvasElement.shapes.length > 0 ||
    annotationCanvasElement.lines.length > 0
  ) {
    saveCurrentAnnotation();
  }

  // Remove event listeners
  document.removeEventListener('keydown', handleAnnotationKeyDown);
  window.removeEventListener('resize', handleAnnotationWindowResize);

  // Restore page scrolling
  document.body.style.overflow = '';
  document.documentElement.style.overflow = '';
  // Remove canvas from DOM
  if (annotationCanvasElement.container.parentNode) {
    annotationCanvasElement.container.parentNode.removeChild(
      annotationCanvasElement.container
    );
  }

  // Update sidebar annotation state if recording is still active
  if (recordingSidebarActive) {
    isAnnotationActive = false;
    // Update the annotation UI to reflect the deactivated state (only if UI elements exist)
    try {
      if (annotationTools && drawingToolButton) {
        updateAnnotationUI();
      }
    } catch (error) {
      console.debug('Error updating annotation UI during deactivation:', error);
    }
  }

  // Clear reference
  annotationCanvasElement = null;
}

var newLine;

/**
 * Handle annotation mouse down events
 */
function handleAnnotationMouseDown(e) {
  if (!annotationCanvasElement) return;

  const pos = annotationCanvasElement.stage.getPointerPosition();
  if (!pos) return;

  // Clicked on the stage - clear selection
  if (e.target === e.target.getStage()) {
    annotationCanvasElement.selectedId = null;
    annotationCanvasElement.transformer.nodes([]);
    annotationCanvasElement.transformerLayer.batchDraw();

    // Store mouse position but don't start drawing yet for shapes
    annotationCanvasElement.mouseDownPos = { x: pos.x, y: pos.y };

    // For pen/highlighter, start immediately as they work differently
    if (annotationTool === 'pen' || annotationTool === 'highlighter') {
      annotationCanvasElement.isDrawing = true;

      const lineWidth =
        annotationTool === 'highlighter'
          ? annotationLineWidth * 2
          : annotationLineWidth;
      const opacity = annotationTool === 'highlighter' ? 0.3 : 1;

      newLine = new Konva.Line({
        id: `line-${Date.now()}`,
        stroke: annotationColor,
        strokeWidth: lineWidth,
        globalCompositeOperation: 'source-over',
        lineCap: 'round',
        lineJoin: 'round',
        points: [pos.x, pos.y],
        draggable: true,
        opacity: opacity,
        tension: 0.5,
      });

      // Add drag end handler for line
      newLine.on('dragend', function (e) {
        handleLineDragEnd(e, newLine.id());
      });

      annotationCanvasElement.layer.add(newLine);
      annotationCanvasElement.currentLine = newLine;
      annotationCanvasElement.lines.push(newLine);
    }
  }

  if (annotationTool === 'eraser') {
    annotationCanvasElement.isDrawing = true;

    newLine = new Konva.Line({
      stroke: '#000',
      strokeWidth: 40,
      globalCompositeOperation: 'destination-out',
      lineCap: 'round',
      lineJoin: 'round',
      points: [pos.x, pos.y],
    });

    annotationCanvasElement.layer.add(newLine);
    annotationCanvasElement.currentLine = newLine;
  }

  // Clicked on a shape - handle selection
  const clickedOnTransformer =
    e.target.getParent()?.className === 'Transformer';
  if (clickedOnTransformer) {
    return;
  }

  // Allow selection in any mode - click on any drawn element to select it
  const id = e.target.id();
  if (id) {
    annotationCanvasElement.selectedId = id;
    // Attach transformer to the selected node
    annotationCanvasElement.transformer.nodes([e.target]);
    annotationCanvasElement.transformerLayer.batchDraw();
  }
}

/**
 * Handle annotation mouse move events
 */
function handleAnnotationMouseMove(e) {
  if (!annotationCanvasElement) return;

  const pos = annotationCanvasElement.stage.getPointerPosition();
  if (!pos) return;

  // If drawing has already started
  if (annotationCanvasElement.isDrawing) {
    if (
      (annotationTool === 'pen' || annotationTool === 'highlighter') &&
      annotationCanvasElement.currentLine
    ) {
      const newPoints = annotationCanvasElement.currentLine
        .points()
        .concat([pos.x, pos.y]);
      annotationCanvasElement.currentLine.points(newPoints);
    }
    if (annotationTool === 'eraser' && annotationCanvasElement.currentLine) {
      const newPoints = annotationCanvasElement.currentLine
        .points()
        .concat([pos.x, pos.y]);
      annotationCanvasElement.currentLine.points(newPoints);
    }

    if (annotationTool === 'square' && annotationCanvasElement.currentShape) {
      const startPos = annotationCanvasElement.startPos;
      annotationCanvasElement.currentShape.width(pos.x - startPos.x);
      annotationCanvasElement.currentShape.height(pos.y - startPos.y);
    }
    if (annotationTool === 'circle' && annotationCanvasElement.currentShape) {
      const startPos = annotationCanvasElement.startPos;
      const radius = Math.sqrt(
        Math.pow(pos.x - startPos.x, 2) + Math.pow(pos.y - startPos.y, 2)
      );
      annotationCanvasElement.currentShape.radius(radius);
    }

    annotationCanvasElement.layer.batchDraw();
    return;
  }

  // Check if we should start drawing based on mouse movement (for shapes only)
  if (
    annotationCanvasElement.mouseDownPos &&
    !annotationCanvasElement.isDrawing &&
    (annotationTool === 'square' || annotationTool === 'circle')
  ) {
    // Calculate how far the mouse has moved
    const dx = pos.x - annotationCanvasElement.mouseDownPos.x;
    const dy = pos.y - annotationCanvasElement.mouseDownPos.y;
    const distance = Math.sqrt(dx * dx + dy * dy);

    // Only start drawing if the mouse has moved more than 5 pixels
    if (distance > 5) {
      annotationCanvasElement.isDrawing = true;

      if (annotationTool === 'square') {
        // Create a new rectangle
        const newRect = new Konva.Rect({
          id: `rect-${Date.now()}`,
          x: annotationCanvasElement.mouseDownPos.x,
          y: annotationCanvasElement.mouseDownPos.y,
          width: dx,
          height: dy,
          stroke: annotationColor,
          strokeWidth: annotationLineWidth,
          fill: 'transparent',
          draggable: true,
        });

        // Add event handlers for rectangle
        newRect.on('dragend', function (e) {
          handleShapeDragEnd(e, newRect.id());
        });

        newRect.on('transformend', function (e) {
          handleTransformEnd(e);
        });

        annotationCanvasElement.layer.add(newRect);
        annotationCanvasElement.currentShape = newRect;
        annotationCanvasElement.shapes.push(newRect);
        annotationCanvasElement.startPos = annotationCanvasElement.mouseDownPos;
      } else if (annotationTool === 'circle') {
        // Create a new circle
        const newCircle = new Konva.Circle({
          id: `circle-${Date.now()}`,
          x: annotationCanvasElement.mouseDownPos.x,
          y: annotationCanvasElement.mouseDownPos.y,
          radius: distance,
          stroke: annotationColor,
          strokeWidth: annotationLineWidth,
          fill: 'transparent',
          draggable: true,
        });

        // Add event handlers for circle
        newCircle.on('dragend', function (e) {
          handleShapeDragEnd(e, newCircle.id());
        });

        newCircle.on('transformend', function (e) {
          handleTransformEnd(e);
        });

        annotationCanvasElement.layer.add(newCircle);
        annotationCanvasElement.currentShape = newCircle;
        annotationCanvasElement.shapes.push(newCircle);
        annotationCanvasElement.startPos = annotationCanvasElement.mouseDownPos;
      }
    }
  }
}

async function solidifyCanvas() {
  const { layer, stage } = annotationCanvasElement;
  const dataURL = layer.toDataURL({ pixelRatio: 1 });

  // Clear everything from layer
  layer.destroyChildren();

  // Create new image from dataURL
  const imageObj = new Image();
  imageObj.src = dataURL;

  imageObj.onload = () => {
    const konvaImage = new Konva.Image({
      image: imageObj,
      x: 0,
      y: 0,
      width: stage.width(),
      height: stage.height(),
      listening: false, // Prevent this image from interfering with interactions
    });

    layer.add(konvaImage);
    layer.batchDraw();

    // Reset tool state
    annotationCanvasElement.currentLine = null;
    annotationCanvasElement.isDrawing = false;
  };
}

/**
 * Handle annotation mouse up events
 */
function handleAnnotationMouseUp() {
  if (!annotationCanvasElement) return;

  // Reset mouse down position regardless of whether we were drawing
  annotationCanvasElement.mouseDownPos = null;

  if (!annotationCanvasElement.isDrawing) return;

  // If we were drawing a line (pen, highlighter, or eraser)
  if (annotationCanvasElement.currentLine) {
    annotationCanvasElement.currentLine = null;
  }

  if (annotationTool === 'eraser') {
    solidifyCanvas(); // Apply the erasing permanently
  }

  // Reset drawing state for all tools
  annotationCanvasElement.isDrawing = false;
  annotationCanvasElement.currentShape = null;
}

/**
 * Handle annotation keyboard events
 */
function handleAnnotationKeyDown(e) {
  if (e.key === 'Escape') {
    // Save annotation before exiting if there's content
    if (
      annotationCanvasElement &&
      (annotationCanvasElement.shapes.length > 0 ||
        annotationCanvasElement.lines.length > 0)
    ) {
      saveCurrentAnnotation();
    }
    deactivateAnnotationCanvas();
  } else if (e.key === 'Delete' || e.key === 'Backspace') {
    handleDeleteSelected();
  }
}

/**
 * Handle window resize for annotation canvas
 */
function handleAnnotationWindowResize() {
  if (!annotationCanvasElement) return;

  const newWidth = window.innerWidth;
  const newHeight = window.innerHeight;

  // Update stage size
  annotationCanvasElement.stage.width(newWidth);
  annotationCanvasElement.stage.height(newHeight);

  // Update container size
  annotationCanvasElement.container.style.width = newWidth + 'px';
  annotationCanvasElement.container.style.height = newHeight + 'px';

  // Redraw all layers
  annotationCanvasElement.layer.batchDraw();
  annotationCanvasElement.transformerLayer.batchDraw();
}

/**
 * Handle line drag end
 */
function handleLineDragEnd(e, lineId) {
  // Lines handle their own position internally, no update needed
}

/**
 * Handle shape drag end
 */
function handleShapeDragEnd(e, shapeId) {
  const index = annotationCanvasElement.shapes.findIndex(
    (shape) => shape.id() === shapeId
  );
  if (index >= 0) {
    // Shape position is updated automatically by Konva
    annotationCanvasElement.layer.batchDraw();
  }
}

/**
 * Handle transform end for shapes
 */
function handleTransformEnd(e) {
  const node = e.target;
  const id = node.id();

  const index = annotationCanvasElement.shapes.findIndex(
    (shape) => shape.id() === id
  );
  if (index >= 0) {
    const shape = annotationCanvasElement.shapes[index];

    if (shape.className === 'Rect') {
      // For rectangles, apply scale to width/height
      const newWidth = Math.abs(node.width() * node.scaleX());
      const newHeight = Math.abs(node.height() * node.scaleY());

      // Handle negative scaling by adjusting position
      let newX = node.x();
      let newY = node.y();

      if (node.scaleX() < 0) {
        newX = newX - newWidth;
      }
      if (node.scaleY() < 0) {
        newY = newY - newHeight;
      }

      // Update the shape
      node.width(newWidth);
      node.height(newHeight);
      node.x(newX);
      node.y(newY);
    } else if (shape.className === 'Circle') {
      // For circles, apply scale to radius
      const maxScale = Math.max(
        Math.abs(node.scaleX()),
        Math.abs(node.scaleY())
      );
      const newRadius = node.radius() * maxScale;
      node.radius(newRadius);
    }

    // Reset scale since we applied it to dimensions
    node.scaleX(1);
    node.scaleY(1);

    annotationCanvasElement.layer.batchDraw();
  }
}

/**
 * Clear the entire canvas
 */
function clearAnnotationCanvas() {
  if (!annotationCanvasElement) return;

  // Clear all shapes and lines
  annotationCanvasElement.shapes.forEach((shape) => shape.destroy());
  annotationCanvasElement.lines.forEach((line) => line.destroy());

  annotationCanvasElement.shapes = [];
  annotationCanvasElement.lines = [];
  annotationCanvasElement.selectedId = null;
  annotationCanvasElement.transformer.nodes([]);

  annotationCanvasElement.layer.batchDraw();
  annotationCanvasElement.transformerLayer.batchDraw();
}

/**
 * Delete selected element
 */
function handleDeleteSelected() {
  if (!annotationCanvasElement || !annotationCanvasElement.selectedId) return;

  const selectedId = annotationCanvasElement.selectedId;

  // Check if it's a shape
  const shapeIndex = annotationCanvasElement.shapes.findIndex(
    (shape) => shape.id && shape.id() === selectedId
  );
  if (shapeIndex >= 0) {
    const shape = annotationCanvasElement.shapes[shapeIndex];
    shape.destroy();
    annotationCanvasElement.shapes.splice(shapeIndex, 1);
    annotationCanvasElement.selectedId = null;
    annotationCanvasElement.transformer.nodes([]);
    annotationCanvasElement.layer.batchDraw();
    annotationCanvasElement.transformerLayer.batchDraw();
    return;
  }

  // Check if it's a line
  const lineIndex = annotationCanvasElement.lines.findIndex(
    (line) => line.id && line.id() === selectedId
  );
  if (lineIndex >= 0) {
    const line = annotationCanvasElement.lines[lineIndex];
    line.destroy();
    annotationCanvasElement.lines.splice(lineIndex, 1);
    annotationCanvasElement.selectedId = null;
    annotationCanvasElement.transformer.nodes([]);
    annotationCanvasElement.layer.batchDraw();
    annotationCanvasElement.transformerLayer.batchDraw();
  }
}

/**
 * Save current annotation using local storage with sessionId
 */
function saveCurrentAnnotation() {
  if (!annotationCanvasElement || !annotationCanvasElement.stage) {
    return;
  }

  try {
    // Check if there are any annotations on the canvas
    const hasAnnotations =
      annotationCanvasElement.shapes.length > 0 ||
      annotationCanvasElement.lines.length > 0;

    if (!hasAnnotations) {
      console.log('No annotations to save');
      return;
    }

    // Generate annotation image - handle tainted canvas
    let annotationBlob = null;
    let annotationBase64 = null;

    try {
      const dataURL = annotationCanvasElement.stage.toDataURL({
        mimeType: 'image/png',
        quality: 0.9,
        pixelRatio: window.devicePixelRatio || 1,
      });

      if (dataURL) {
        // Convert dataURL to Blob
        const base64Data = dataURL.split(',')[1];
        const binaryString = atob(base64Data);
        const bytes = new Uint8Array(binaryString.length);

        for (let i = 0; i < binaryString.length; i++) {
          bytes[i] = binaryString.charCodeAt(i);
        }

        annotationBlob = new Blob([bytes], { type: 'image/png' });
        annotationBase64 = dataURL;
        console.log('Created annotation blob, size:', annotationBlob.size);
      }
    } catch (canvasError) {
      console.debug(
        'Canvas is tainted, cannot export annotation image:',
        canvasError
      );
    }

    if (!annotationBlob) {
      console.log('Could not create annotation blob');
      return;
    }

    // Create session metadata using the same format as recording sessions
    const metadata = {
      title: document.title || 'Annotation Session',
      url: window.location.href,
      timestamp: new Date().toISOString(),
      duration: 0,
      formattedDuration: '00:00',
      pageTitle: document.title,
      hasAudio: false,
      hasScreenshot: false,
      hasAnnotation: true,
      content: 'No prompt generated yet.',
    };

    // Store annotation data for the main recording flow instead of creating separate session
    if (typeof window.pendingAnnotationData === 'undefined') {
      window.pendingAnnotationData = {};
    }
    window.pendingAnnotationData = {
      annotationBlob: annotationBlob,
      hasAnnotation: true,
    };
    console.log('Annotation data stored for main recording flow');
  } catch (error) {
    console.error('Error saving annotation:', error);
  }
}

// Create the floating widget
function createWidget() {
  if (widget) {
    // If widget already exists, make sure it's visible
    if (widget.style.display === 'none') {
      widget.style.display = 'flex';
    }
    widgetVisible = true;
    return widget; // Return existing widget
  }

  // Create widget element
  widget = document.createElement('div');
  widget.id = 'ai-prompt-builder-widget';
  widget.style.position = 'fixed';
  widget.style.left = '20px'; // Changed to left side
  widget.style.top = '50%';
  widget.style.transform = 'translateY(-50%)';
  widget.style.transform = 'translateX(-50%)';
  widget.style.width = '48px';
  widget.style.height = '48px';
  widget.style.borderRadius = '50%';
  widget.style.backgroundColor = '#4F46E5';
  widget.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.3)';
  widget.style.cursor = 'pointer';
  widget.style.zIndex = '9999';
  widget.style.display = 'flex';
  widget.style.alignItems = 'center';
  widget.style.justifyContent = 'center';
  widget.style.color = 'white';
  widget.style.fontWeight = 'bold';
  widget.style.fontSize = '16px';
  widget.style.transition = 'all 0.3s ease';

  // Add AI text to the widget
  widget.textContent = 'AI';

  // Make the widget draggable
  let isDragging = false;
  let startX = 0;
  let startY = 0;
  let startLeft = 0;
  let startTop = 0;

  widget.addEventListener('mousedown', function (e) {
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    startLeft = parseInt(widget.style.left || '0');
    startTop = parseInt(widget.style.top || '0');

    // Prevent default behavior to avoid text selection
    e.preventDefault();
  });

  document.addEventListener('mousemove', function (e) {
    if (!isDragging) return;

    // Calculate the new position
    const deltaX = e.clientX - startX;
    const deltaY = e.clientY - startY;

    // Update widget position based on whether it's positioned with 'right' or 'left'
    if (widget.style.right) {
      widget.style.right = startLeft - deltaX + 'px';
      widget.style.left = ''; // Clear 'left' if it was set
    } else {
      widget.style.left = startLeft + deltaX + 'px';
      widget.style.right = ''; // Clear 'right' if it was set
    }

    widget.style.top = startTop + deltaY + 'px';
    widget.style.transform = 'none'; // Remove centering transform
  });

  document.addEventListener('mouseup', function () {
    isDragging = false;
  });

  // Hover effects
  widget.addEventListener('mouseenter', function () {
    widget.style.transform =
      widget.style.transform === 'none'
        ? 'scale(1.1)'
        : 'translateY(-50%) scale(1.1)';
  });

  widget.addEventListener('mouseleave', function () {
    widget.style.transform =
      widget.style.transform === 'none'
        ? 'scale(1)'
        : 'translateY(-50%) scale(1)';
  });

  // Add click handler to open the sidebar
  widget.addEventListener('click', function () {
    // Only trigger click if we're not dragging
    if (!isDragging) {
      // Send message to background script to open the sidebar
      try {
        chrome.runtime.sendMessage(
          {
            type: 'OPEN_SIDE_PANEL',
          },
          function (response) {
            if (chrome.runtime.lastError) {
              console.error(
                'Error opening side panel:',
                chrome.runtime.lastError
              );
            }
          }
        );
      } catch (error) {
        console.error('Exception sending message to open panel:', error);
      }
    }
  });

  // Append the widget to the document body
  document.body.appendChild(widget);
  widgetVisible = true;

  // Add animation styles
  addAnimationStyles();

  return widget;
}

// Hide the widget
function hideWidget() {
  if (widget) {
    widget.style.display = 'none';
    widgetVisible = false;
  }
}

function createCountdownOverlay(ID) {
  if (countdownActive) return;

  if (annotateOnlyMode) {
    createRecordingSidebar(ID);
    return;
  }

  countdownActive = true;
  let countdownValue = 3;
  const endTime = Date.now() + countdownValue * 1000;

  const overlay = document.createElement('div');
  overlay.id = '__countdown_overlay__';
  Object.assign(overlay.style, {
    position: 'fixed',
    top: '0',
    left: '0',
    width: '100%',
    height: '100%',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    zIndex: '99999',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    transition: 'opacity 0.3s ease',
    opacity: '1',
  });

  const contentContainer = document.createElement('div');
  Object.assign(contentContainer.style, {
    position: 'relative',
    textAlign: 'center',
  });

  const countdownElement = document.createElement('div');
  Object.assign(countdownElement.style, {
    fontSize: '160px', // fixed px instead of rem for consistent height
    lineHeight: '1',   // remove extra vertical font padding
    color: 'white',
    fontWeight: 'bold',
    fontFamily: 'Arial, sans-serif',
    transition: 'transform 0.3s ease, opacity 0.3s ease',
  });
  countdownElement.textContent = countdownValue.toString();

  const skipHint = document.createElement('div');
  Object.assign(skipHint.style, {
    position: 'absolute',
    top: 'calc(100% + 25px)', // fixed gap below the number
    left: '50%',
    transform: 'translateX(-50%)',
    fontSize: '20px',
    color: 'rgba(255,255,255,0.8)',
    fontFamily: 'Arial, sans-serif',
    opacity: '0',
    transition: 'opacity 0.5s ease',
    whiteSpace: 'nowrap',
  });
  skipHint.textContent = 'Press Space or Enter to start now';

  contentContainer.appendChild(countdownElement);
  contentContainer.appendChild(skipHint);
  overlay.appendChild(contentContainer);
  document.body.appendChild(overlay);

  setTimeout(() => {
    skipHint.style.opacity = '1';
  }, 500);

  const startRecording = () => {
    clearTimeout(timerId);
    document.removeEventListener('keydown', skipHandler);
    document.removeEventListener('visibilitychange', syncOnVisibilityChange);
    overlay.style.opacity = '0';
    setTimeout(() => overlay.remove(), 300);
    countdownActive = false;

    requestAudioPermission()
      .then(() => createRecordingSidebar(ID))
      .catch((error) => {
        console.error('Audio permission error:', error);
        createRecordingSidebar(ID);
      });
  };

  const skipHandler = (e) => {
    if (e.code === 'Space' || e.code === 'Enter') {
      e.preventDefault();
      startRecording();
    }
  };

  document.addEventListener('keydown', skipHandler);

  const updateCountdown = () => {
    const remaining = Math.ceil((endTime - Date.now()) / 1000);

    if (remaining !== countdownValue && remaining > 0) {
      countdownValue = remaining;
      countdownElement.style.transform = 'scale(0.7)';
      countdownElement.style.opacity = '0';
      setTimeout(() => {
        countdownElement.textContent = countdownValue.toString();
        countdownElement.style.transform = 'scale(1)';
        countdownElement.style.opacity = '1';
      }, 150);
    }

    if (remaining <= 0) {
      startRecording();
    } else {
      const msUntilNextSecond = (endTime - Date.now()) % 1000 || 1000;
      timerId = setTimeout(updateCountdown, msUntilNextSecond);
    }
  };

  const syncOnVisibilityChange = () => {
    if (!document.hidden) updateCountdown();
  };

  document.addEventListener('visibilitychange', syncOnVisibilityChange);

  let timerId = setTimeout(updateCountdown, 1000);
}



/**
 * Takes a screenshot of the visible area and sends it to the background script
 * This is the simple screenshot function for the screenshot button
 */
function takeScreenshot() {
  try {
    // Send message to background script to take screenshot
    chrome.runtime.sendMessage(
      {
        type: 'TAKE_SCREENSHOT',
      },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error('Error taking screenshot:', chrome.runtime.lastError);
          return;
        }

        if (response && response.success) {
          // Set manual screenshot flag and convert to blob
          manualScreenshotTaken = true;

          try {
            // Convert dataURL to blob for session storage
            const dataUrl = response.screenshot;
            const arr = dataUrl.split(',');
            const mimeType = arr[0].match(/:(.*?);/)[1];
            const binaryString = atob(arr[1]);
            const bytes = new Uint8Array(binaryString.length);

            for (let i = 0; i < binaryString.length; i++) {
              bytes[i] = binaryString.charCodeAt(i);
            }

            screenshotBlob = new Blob([bytes], { type: mimeType });
            console.log(
              'Manual screenshot blob created, size:',
              screenshotBlob.size
            );
          } catch (error) {
            console.error('Error converting manual screenshot to blob:', error);
          }

          // Store the screenshot
          const currentUrl = window.location.href;
          const timestamp = new Date().toISOString();

          // Create a screenshot object
          const screenshotData = {
            url: currentUrl,
            timestamp: timestamp,
            dataUrl: response.screenshot,
            type: 'manual', // This is a manual screenshot
          };

          // Store the screenshot
          if (!capturedScreenshots[currentUrl]) {
            capturedScreenshots[currentUrl] = [];
          }

          capturedScreenshots[currentUrl].push(screenshotData);

          // Update sessionData with manual screenshot for session preview
          sessionData.screenshot = response.screenshot;

          // Flash effect to indicate screenshot was taken
          flashScreenshotEffect();
        } else {
          console.error('Screenshot failed:', response?.error);
        }
      }
    );
  } catch (error) {
    console.error('Exception taking screenshot:', error);
  }
}

/**
 * Creates a flash effect to indicate a screenshot was taken
 */
function flashScreenshotEffect() {
  const flash = document.createElement('div');
  flash.style.position = 'fixed';
  flash.style.top = '0';
  flash.style.left = '0';
  flash.style.width = '100%';
  flash.style.height = '100%';
  flash.style.backgroundColor = 'white';
  flash.style.opacity = '0.8';
  flash.style.zIndex = '99999';
  flash.style.pointerEvents = 'none';
  flash.style.transition = 'opacity 0.5s ease-out';

  document.body.appendChild(flash);

  // Fade out the flash effect
  setTimeout(() => {
    flash.style.opacity = '0';
    setTimeout(() => {
      document.body.removeChild(flash);
    }, 500);
  }, 100);
}


function findMainScrollContainer(minScrollRatio = 1.2, minDimensionPx = 400) {
  const doc = document.documentElement;

  // Only consider window if viewport dimensions are >= minDimensionPx
  const viewportHeight = window.innerHeight;
  const viewportWidth = window.innerWidth;

  if (viewportHeight >= minDimensionPx && viewportWidth >= minDimensionPx) {
    const windowScrollableY = doc.scrollHeight > viewportHeight * minScrollRatio;
    const windowScrollableX = doc.scrollWidth > viewportWidth * minScrollRatio;

    if (windowScrollableY || windowScrollableX) {
      return window;
    }
  }

  // Otherwise, find best scrollable element in the DOM
  const all = [...document.querySelectorAll('*')];
  let best = doc;  // fallback
  let bestScore = 0;

  for (const el of all) {
    const style = getComputedStyle(el);
    const scrollableY = ['auto', 'scroll'].includes(style.overflowY);
    const scrollableX = ['auto', 'scroll'].includes(style.overflowX);
    const scrollHeight = el.scrollHeight;
    const scrollWidth = el.scrollWidth;
    const clientHeight = el.clientHeight;
    const clientWidth = el.clientWidth;

    if ((scrollableY && scrollHeight > clientHeight * minScrollRatio) ||
        (scrollableX && scrollWidth > clientWidth * minScrollRatio)) {

      // Skip elements smaller than minDimensionPx in height and width
      if (clientHeight < minDimensionPx && clientWidth < minDimensionPx) continue;

      const verticalOverflow = scrollableY ? scrollHeight - clientHeight : 0;
      const horizontalOverflow = scrollableX ? scrollWidth - clientWidth : 0;
      const score = verticalOverflow + horizontalOverflow;

      if (score > bestScore) {
        best = el;
        bestScore = score;
      }
    }
  }

  return best || window;
}




class ScrollFootprintTracker {
  constructor(scrollContainer = window) {
    this.scrollContainer = scrollContainer;
    this.isWindow = scrollContainer === window;
    this.boundScrollHandler = this.handleScroll.bind(this);
    this.boundVisibilityHandler = this.handleVisibilityChange.bind(this);
    this.reset();
  }

  reset() {
    if (this.isWindow) {
      this.viewportHeight = window.innerHeight;
      this.documentHeight = Math.max(
        document.body.scrollHeight,
        document.documentElement.scrollHeight
      );
    } else {
      this.viewportHeight = this.scrollContainer.clientHeight;
      this.documentHeight = this.scrollContainer.scrollHeight;
    }

    const numSlices = Math.ceil(this.documentHeight / this.viewportHeight);
    console.log(numSlices)
    this.slices = Array(numSlices).fill(0);
    this.currentSlice = 0;
    this.lastUpdateTime = 0;
    this.url = window.location.href;


  }

  start() {
    if (this.isTracking) return;
    this.isTracking = true;
    this.lastUpdateTime = Date.now();

    this.scrollContainer.addEventListener("scroll", this.boundScrollHandler, {
      passive: true,
    });
    document.addEventListener("visibilitychange", this.boundVisibilityHandler);

    this.calculateCurrentSlice();
  }

  stop() {
    if (!this.isTracking) return;

    this.updateCurrentSliceDwellTime();
    this.scrollContainer.removeEventListener("scroll", this.boundScrollHandler);
    document.removeEventListener("visibilitychange", this.boundVisibilityHandler);
    this.isTracking = false;

    return this.getFootprint();
  }

  handleScroll() {

    this.updateCurrentSliceDwellTime();
    this.calculateCurrentSlice();
    this.lastUpdateTime = Date.now();

    console.log("  - currentSlice:", this.currentSlice);
    console.log("  - slices:", this.slices);
  }

  handleVisibilityChange() {
    if (document.hidden) {
      this.updateCurrentSliceDwellTime();
      this.isHidden = true;
    } else {
      this.lastUpdateTime = Date.now();
      this.isHidden = false;
    }
  }

  calculateCurrentSlice() {
    const scrollY = this.isWindow
      ? window.scrollY || window.pageYOffset
      : this.scrollContainer.scrollTop;

    this.currentSlice = Math.floor(scrollY / this.viewportHeight);
  }

  updateCurrentSliceDwellTime() {
    if (this.isHidden) {
      return;
    }

    const now = Date.now();
    const dwellTime = now - this.lastUpdateTime;

    if (this.currentSlice >= 0 && this.currentSlice < this.slices.length) {
      this.slices[this.currentSlice] += dwellTime;
    }

    this.lastUpdateTime = now;
  }

  getFootprint() {
    this.updateCurrentSliceDwellTime();

    const result = {
      url: this.url,
      viewportHeight: this.viewportHeight,
      documentHeight: this.documentHeight,
      slices: [...this.slices],
      timestamp: new Date().toISOString(),
    };

    return result;
  }

  getSignificantSliceRange() {

    const significantThresholdMs = 2000;
    let firstSignificantSlice = -1;
    let lastSignificantSlice = -1;

    const isShortPage = this.documentHeight <= this.viewportHeight * 1.5;

    if (isShortPage) {
      return {
        firstSlice: 0,
        lastSlice: Math.ceil(this.documentHeight / this.viewportHeight),
        yStart: 0,
        yEnd: this.documentHeight,
        isShortPage: true,
      };
    }

    for (let i = 0; i < this.slices.length; i++) {
      if (this.slices[i] >= significantThresholdMs) {
        firstSignificantSlice = i;
        break;
      }
    }

    for (let i = this.slices.length - 1; i >= 0; i--) {
      if (this.slices[i] >= significantThresholdMs) {
        lastSignificantSlice = i;
        break;
      }
    }

    if (firstSignificantSlice === -1 || lastSignificantSlice === -1) {
      for (let i = 0; i < this.slices.length; i++) {
        if (this.slices[i] > 0 && firstSignificantSlice === -1) {
          firstSignificantSlice = i;
        }
        if (this.slices[i] > 0) {
          lastSignificantSlice = i;
        }
      }

      if (firstSignificantSlice === -1 || lastSignificantSlice === -1) {
        firstSignificantSlice = 0;
        lastSignificantSlice = 0;
      }
    }

    const range = {
      firstSlice: firstSignificantSlice,
      lastSlice: lastSignificantSlice,
      yStart: firstSignificantSlice * this.viewportHeight,
      yEnd: Math.min((lastSignificantSlice + 1) * this.viewportHeight, this.documentHeight),
      isShortPage: false,
    };

    return range;
  }
}

/**
 * Takes a context-aware screenshot based on scroll tracking data
 * This captures the areas where the user spent the most time
 */
async function takeContextAwareScreenshot() {
  if (!scrollFootprintTracker) {
    console.error("Scroll footprint tracker not initialized");
    return null;
  }

  // Get the current scroll tracking data
  const scrollData = scrollFootprintTracker.getFootprint();
  const sliceRange = scrollFootprintTracker.getSignificantSliceRange();

  if (!sliceRange) {
    console.log("No significant slices found, taking simple screenshot");
    return takeSimpleScreenshot();
  }

  try {
    const currentUrl = window.location.href;
    const timestamp = new Date().toISOString();
    let screenshotDataUrl;

    // If this is a short page, take a simple screenshot
    if (sliceRange.isShortPage) {
      screenshotDataUrl = await takeSimpleScreenshot();
    } else {
      // For larger pages, capture the significant area
      screenshotDataUrl = await capturePageSection(
        sliceRange.yStart,
        sliceRange.yEnd,
        scrollFootprintTracker.viewportHeight,
        scrollFootprintTracker.scrollContainer
      );
    }

    if (screenshotDataUrl) {
      // Store the screenshot data
      const screenshotData = {
        url: currentUrl,
        timestamp: timestamp,
        dataUrl: screenshotDataUrl,
        type: "context",
        sliceRange: {
          firstSlice: sliceRange.firstSlice,
          lastSlice: sliceRange.lastSlice,
          yStart: sliceRange.yStart,
          yEnd: sliceRange.yEnd,
        },
        footprint: scrollData,
      };

      // Store the screenshot
      if (!capturedScreenshots[currentUrl]) {
        capturedScreenshots[currentUrl] = [];
      }

      capturedScreenshots[currentUrl].push(screenshotData);
      return screenshotData;
    }
  } catch (error) {
    console.error("Error taking context-aware screenshot:", error);
  }

  return null;
}
const MAX_CALLS_PER_SECOND = 2; 
const CALL_INTERVAL_MS = 1000 / MAX_CALLS_PER_SECOND;

let previouslyHidden = [];


async function capturePageSection(yStart, yEnd, viewportHeight, scrollContainer = window) {
  const isWindow = scrollContainer === window;
  const originalScrollY = isWindow ? window.scrollY : scrollContainer.scrollTop;
  const captures = [];
  const scrollOffsets = [];

  try {
    const numScrolls = Math.ceil((yEnd - yStart) / viewportHeight);
    const maxScrollY = isWindow
      ? document.documentElement.scrollHeight - window.innerHeight
      : scrollContainer.scrollHeight - scrollContainer.clientHeight;

    // Hide sticky elements once
    const hiddenSticky = hideAllStickyElements(scrollContainer);


    for (let i = 0; i < numScrolls; i++) {
   
      const targetScrollY = Math.min(yStart + i * viewportHeight, maxScrollY);
      if (isWindow) {
        window.scrollTo(0, targetScrollY);
      } else {
        scrollContainer.scrollTop = targetScrollY;
      }

      await waitForScrollPosition(scrollContainer, targetScrollY);
      await delay(CALL_INTERVAL_MS);

      // Detect and hide repeated elements after the first capture
       const actualScrollY = isWindow ? window.scrollY : scrollContainer.scrollTop;
      scrollOffsets.push(actualScrollY);
      const dataUrl = await takeSimpleScreenshot();
      captures.push(dataUrl);
    }

    restoreElementsVisibility(hiddenSticky);

    if (isWindow) window.scrollTo(0, originalScrollY);
    else scrollContainer.scrollTop = originalScrollY;

    return await stitchImages(captures, scrollOffsets);
  } catch (error) {
    console.error("Error capturing page section:", error);
    return null;
  } finally {

    if (isWindow) window.scrollTo(0, originalScrollY);
    else scrollContainer.scrollTop = originalScrollY;
  }

}




function recordElementRects() {
  const map = new Map();
  const elements = document.querySelectorAll("body *");
  elements.forEach(el => {
    if (!(el instanceof HTMLElement)) return;
    if (el.offsetWidth === 0 || el.offsetHeight === 0) return;
    const rect = el.getBoundingClientRect();
    map.set(el, {
      top: rect.top,
      left: rect.left,
      width: rect.width,
      height: rect.height
    });
  });
  return map;
}


function hideAllStickyElements(mainContainer = null) {
  const elements = Array.from(document.querySelectorAll("*"));
  const hiddenElements = new Map();
  const originalScrollY = window.scrollY;

  const initialRects = new Map();
  elements.forEach(el => {
    if (el instanceof HTMLElement) {
      initialRects.set(el, el.getBoundingClientRect());
    }
  });

  const start = performance.now();
  while (performance.now() - start < 50); // wait ~50ms

  elements.forEach(el => {
    if (!(el instanceof HTMLElement)) return;

    const style = getComputedStyle(el);
    if (style.display === "none" || el.offsetHeight === 0 || el.offsetWidth === 0) return;

if (
  (mainContainer instanceof HTMLElement && mainContainer.contains(el)) ||
  mainContainer === window
) {
  return;  
}

    const initial = initialRects.get(el);
    if (!initial) return;
    const current = el.getBoundingClientRect();
    const deltaY = Math.abs(current.top - initial.top);

    const isStickyOrFixed = style.position === "fixed" || style.position === "sticky";
    const isLarge = el.offsetHeight * el.offsetWidth > window.innerHeight * window.innerWidth * 0.5;

    if (isStickyOrFixed && deltaY < 2 && !isLarge) {
      hiddenElements.set(el, el.style.display);
      el.style.display = "none";
    }
  });

  return hiddenElements;
}


function restoreElementsVisibility(hiddenElements) {
  hiddenElements.forEach((display, el) => {
    el.style.display = display || "";
  });
}




async function waitForScrollPosition(container, targetY, timeout = 2000, interval = 20) {
  const isWindow = container === window;
  const getScrollTop = isWindow
    ? () => window.scrollY
    : () => container.scrollTop;

  const doScroll = () => {
    if (isWindow) window.scrollTo(0, targetY);
    else container.scrollTop = targetY;
    return new Promise(r => requestAnimationFrame(() => setTimeout(r, 10)));
  };

  async function waitOnce() {
    const start = Date.now();

    return new Promise((resolve, reject) => {
      const check = () => {
        const current = getScrollTop();
        if (Math.abs(current - targetY) < 1) return resolve(); // ✅ tolerant match
        if (Date.now() - start > timeout) return reject(new Error("Scroll timeout exceeded"));
        setTimeout(check, interval);
      };
      check();
    });
  }

  try {
    await waitOnce();
  } catch (err) {
    // Force scroll again and retry
    await doScroll();
    await waitOnce(); // second attempt
  }
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Stitches multiple screenshots into a single tall image
 */
async function stitchImages(imageDataUrls, yOffsets) {
  const images = await Promise.all(
    imageDataUrls.map(async (url) => {
      const img = new Image();
      img.src = url;
      await img.decode();
      return img;
    })
  );

  const width = images[0].naturalWidth;
  const heights = images.map(img => img.naturalHeight);
  const totalHeight = heights.reduce((sum, h) => sum + h, 0);

  const canvas = document.createElement("canvas");
  canvas.width = width;
  canvas.height = totalHeight;
  const ctx = canvas.getContext("2d");

  let currentY = 0;
  for (let i = 0; i < images.length; i++) {
    ctx.drawImage(images[i], 0, Math.round(currentY));

    currentY += images[i].naturalHeight;
  }

  return canvas.toDataURL("image/png");
}


function loadImage(dataUrl) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve(img);
    img.onerror = reject;
    img.src = dataUrl;
  });
}


/**
 * Takes a simple screenshot of the current viewport
 */
function takeSimpleScreenshot() {
  return new Promise((resolve, reject) => {
    try {
      chrome.runtime.sendMessage(
        {
          type: "TAKE_SCREENSHOT",
        },
        function (response) {
          if (chrome.runtime.lastError) {
            reject(chrome.runtime.lastError);
            return;
          }

          if (response && response.success) {
            resolve(response.screenshot);
          } else {
            reject(response?.error || "Unknown error");
          }
        },
      );
    } catch (error) {
      reject(error);
    }
  });
}




// Create the recording sidebar UI
function createRecordingSidebar(recordingSessionId) {
  if (recordingSidebarActive) {
    return;
  }

if (!scrollFootprintTracker) {
  const scrollContainer = findMainScrollContainer();
  console.log(scrollContainer)
  scrollFootprintTracker = new ScrollFootprintTracker(scrollContainer);
}

scrollFootprintTracker.reset(); 
scrollFootprintTracker.start();

  recordingSidebarActive = true;
  isAnnotationActive = false;

  // Create the recording sidebar
  const sidebar = document.createElement('div');
  sidebar.id = 'ai-prompt-builder-recording-sidebar';
  sidebar.style.position = 'fixed';
  sidebar.style.left = '20px'; // Default position on left side
  sidebar.style.top = '50%';
  sidebar.style.setProperty('transform', 'translateY(-50%)', 'important');
  sidebar.style.display = 'flex';
  sidebar.style.flexDirection = 'column';
  sidebar.style.alignItems = 'center';
  sidebar.style.backgroundColor = 'white';
  sidebar.style.padding = '12px';
  sidebar.style.borderRadius = '12px';
  sidebar.style.boxShadow = '0 4px 20px rgba(0, 0, 0, 0.15)';
  sidebar.style.zIndex = '99998';
  sidebar.style.transition = 'all 0.3s ease';
  adjustSize();
  // Create the inner container for all elements
  const innerContainer = document.createElement('div');
  innerContainer.style.display = 'flex';
  innerContainer.style.flexDirection = 'column';
  innerContainer.style.alignItems = 'center';
  innerContainer.style.padding = '3px';
  innerContainer.style.gap = '16px';

  // Logo and Timer section
  const headerSection = document.createElement('div');
  headerSection.style.display = 'flex';
  headerSection.style.flexDirection = 'column';
  headerSection.style.alignItems = 'center';
  headerSection.style.gap = '8px';
  headerSection.style.gap = '8px';
  headerSection.style.pointerEvents = 'none';
  // User avatar with FP initials
  const avatar = document.createElement('div');
  avatar.style.width = '40px';
  avatar.style.height = '40px';
  avatar.style.borderRadius = '50%';
  avatar.style.backgroundColor = '#5845FF'; // Purple color
  avatar.style.color = 'white';
  avatar.style.display = 'flex';
  avatar.style.alignItems = 'center';
  avatar.style.justifyContent = 'center';
  avatar.style.fontWeight = 'bold';
  avatar.style.fontSize = '16px';
  avatar.style.fontFamily = 'system-ui';
  avatar.textContent = 'FP';
  // Timer container with red dot
  const timerContainer = document.createElement('div');
  timerContainer.style.display = 'flex';
  timerContainer.style.flexDirection = 'column';
  timerContainer.style.alignItems = 'center';

  // Red recording dot - only show if audio recording is active
  const recordingDot = document.createElement('div');
  recordingDot.style.width = '8px';
  recordingDot.style.height = '8px';
  recordingDot.style.borderRadius = '50%';
  recordingDot.style.backgroundColor = isRecording ? '#FF3B30' : '#888888'; // Gray if not recording
  recordingDot.style.animation = isRecording ? 'pulse 1.5s infinite' : 'none';

  // Recording status text for screenshot-only mode
  const statusText = document.createElement('div');
  statusText.style.fontSize = '10px';
  statusText.style.color = '#333';
  statusText.style.marginTop = '2px';
  statusText.style.textAlign = 'center';
  statusText.style.maxWidth = '60px';
  statusText.textContent = isRecording ? 'Recording' : 'Screenshot Only';
  statusText.style.display = isRecording ? 'none' : 'block';

  // Timer display
  const timer = document.createElement('span');
  timer.id = '__recording_timer__'
  timer.style.fontSize = '12px';
  timer.style.fontFamily = 'system-ui';
  timer.style.color = '#333';
  timer.style.marginTop = '4px';
  timer.textContent = '00:00';
  timer.style.display = hasAudioPermission  ? 'block' : 'none';

  // Add timer elements
  timerContainer.appendChild(recordingDot);
  timerContainer.appendChild(statusText);
  timerContainer.appendChild(timer);

  // Add header elements
  headerSection.appendChild(avatar);
  headerSection.appendChild(timerContainer);

  // Audio visualization/progress bars section with fixed dimensions
  const audioVisualization = document.createElement('div');
  audioVisualization.style.display = isRecording ? 'flex' : 'none'; // Only show when recording audio
  audioVisualization.style.flexDirection = 'column';
  audioVisualization.style.alignItems = 'center';
  audioVisualization.style.justifyContent = 'space-between';
  audioVisualization.style.marginTop = '8px';
  audioVisualization.style.marginBottom = '8px';
  audioVisualization.style.width = '30px'; // Fixed width container
  audioVisualization.style.height = '64px'; // Fixed height: 8 bars x 4px height + 7 gaps x 4px
  audioVisualization.style.overflow = 'hidden'; // Prevent overflow

  // Create 8 audio level bars with fixed dimensions
  for (let i = 0; i < 8; i++) {
    const bar = document.createElement('div');
    bar.style.width = '30px'; // Fixed width
    bar.style.height = '4px'; // Fixed height
    bar.style.backgroundColor = '#E0E0E0'; // Default to gray
    bar.style.borderRadius = '2px';
    bar.style.marginBottom = '4px'; // Consistent spacing
    // Only transition background color, not dimensions
    bar.style.transition = 'background-color 0.1s ease';
    audioVisualization.appendChild(bar);
  }

  // Tool controls section
  const toolsSection = document.createElement('div');
  toolsSection.style.display = 'flex';
  toolsSection.style.flexDirection = 'column';
  toolsSection.style.alignItems = 'center';
  toolsSection.style.gap = '12px';
  toolsSection.style.marginTop = '8px';

  // Drawing tools button
  drawingToolButton = document.createElement('button');
  drawingToolButton.className = '__injected_main_buttons__';

  drawingToolButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 19l7-7 3 3-7 7-3-3z"></path>
    <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path>
    <path d="M2 2l7.586 7.586"></path>
    <circle cx="11" cy="11" r="2"></circle>
  </svg>`;

const tooltipWrapper = document.createElement('div');
tooltipWrapper.style.position = 'relative';
tooltipWrapper.style.display = 'inline-block';


const autoModeToggleButton = document.createElement('button');
autoModeToggleButton.className = '__injected_main_buttons__';

// 2. Define the SVGs
const autoScreenshotToggleOffSvg = `
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
     viewBox="0 0 24 24" fill="white" stroke="#000" 
     stroke-width="1" stroke-linecap="round" stroke-linejoin="round">
  <rect x="2" y="6" width="20" height="12" rx="6" />
  <circle cx="8" cy="12" r="4" />
</svg>`;

const autoScreenshotToggleOnSvg = `
<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24"
     viewBox="0 0 24 24" fill="white" stroke="#000" 
     stroke-width="1" stroke-linecap="round" stroke-linejoin="round">
  <rect x="2" y="6" width="20" height="12" rx="6" />
  <circle cx="16" cy="12" r="4" />
</svg>`;

// 3. Initial state
let audioOnly = false;
autoModeToggleButton.innerHTML = autoScreenshotToggleOffSvg;

// 4. Add toggle logic
autoModeToggleButton.addEventListener('click', () => {
  audioOnly = !audioOnly;
  autoModeToggleButton.innerHTML = audioOnly
    ? autoScreenshotToggleOnSvg
    : autoScreenshotToggleOffSvg;
  tooltip.innerText = `Audio-only mode: ${audioOnly ? 'On' : 'Off'}`;

});


// 3. Create the tooltip span
const tooltip = document.createElement('span');
  tooltip.innerText = `Audio-only mode: ${audioOnly ? 'On' : 'Off'}`;
tooltip.style.cssText = `
  visibility: hidden;
  background-color: #333;
  color: #fff;
  font-family: system-ui;
  text-align: center;
  padding: 4px 8px;
  border-radius: 4px;
  position: absolute;
  z-index: 999;
  bottom: 8px;
  left: 250%;
  transform: translateX(-50%);
  opacity: 0;
  transition: opacity 0.3s;
  white-space: nowrap;
  font-size: 12px;
`;

// 4. Show/hide on hover
tooltipWrapper.addEventListener('mouseenter', () => {
  tooltip.style.visibility = 'visible';
  tooltip.style.opacity = '1';
});
tooltipWrapper.addEventListener('mouseleave', () => {
  tooltip.style.visibility = 'hidden';
  tooltip.style.opacity = '0';
});

// 5. Assemble it all
tooltipWrapper.appendChild(autoModeToggleButton);
tooltipWrapper.appendChild(tooltip);


  // Create annotation tools section early so it's available for updateAnnotationUI
  annotationTools = document.createElement('div');
  annotationTools.id = 'annotation-tools';
  annotationTools.style.display = 'none';
  annotationTools.style.flexDirection = 'column';
  annotationTools.style.alignItems = 'center';
  annotationTools.style.gap = '12px';
  annotationTools.style.marginTop = '12px';

  // Create all annotation tool buttons immediately
  // Pen tool
  const penTool = document.createElement('button');
  penTool.className = '__injected_button_sidebar__ __injected_pentool__';
  penTool.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 19l7-7 3 3-7 7-3-3z"></path>
    <path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18l5-5z"></path>
  </svg>`;

  // Square tool
  const squareTool = document.createElement('button');
  squareTool.className = '__injected_button_sidebar__';
  squareTool.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect>
  </svg>`;

  // Circle tool
  const circleTool = document.createElement('button');
  circleTool.className = '__injected_button_sidebar__';
  circleTool.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <circle cx="12" cy="12" r="10"></circle>
  </svg>`;

  // Eraser tool
  const eraserTool = document.createElement('button');
  eraserTool.className = '__injected_button_sidebar__';
  eraserTool.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 20H7l-7-7 8-8 3 3h9v12z"></path>
    <path d="M7 20l3-3H4"></path>
  </svg>`;

  // Color palette
  const colorPalette = document.createElement('div');
  colorPalette.className = '__injected_color_palette__';

  // Colors
  const colors = [
    { name: 'pink', hex: '#ec4899' },
    { name: 'green', hex: '#10b981' },
    { name: 'blue', hex: '#3b82f6' },
    { name: 'orange', hex: '#f59e0b' },
  ];

  // Track the currently selected color
  let selectedColor = colors[0]; // Default to the first color (pink)

  // Create color buttons
  colors.forEach((color, index) => {
    const colorButton = document.createElement('button');
    colorButton.style.width = '16px';
    colorButton.style.height = '16px';
    colorButton.style.borderRadius = '50%';
    colorButton.style.backgroundColor = color.hex;
    colorButton.style.border = index === 0 ? '2px solid #000' : 'none';
    colorButton.style.cursor = 'pointer';
    colorButton.style.margin = '0 auto';
    colorButton.style.padding = '0';

    colorButton.addEventListener('click', () => {
      colorPalette.querySelectorAll('button').forEach((btn) => {
        btn.style.border = 'none';
      });
      colorButton.style.border = '2px solid #000';
      selectedColor = color.hex;
      annotationColor = color.hex;
    });

    colorPalette.appendChild(colorButton);
  });

  // Add click handlers for annotation tools
  penTool.addEventListener('click', function () {
    annotationTool = 'pen';
    updateToolSelection(penTool);
  });

  squareTool.addEventListener('click', function () {
    annotationTool = 'square';
    updateToolSelection(squareTool);
  });

  circleTool.addEventListener('click', function () {
    annotationTool = 'circle';
    updateToolSelection(circleTool);
  });

  eraserTool.addEventListener('click', function () {
    annotationTool = 'eraser';
    updateToolSelection(eraserTool);
  });

  function updateToolSelection(selectedTool) {
    resetAnnotationDrawingState();

    const tools = [penTool, squareTool, circleTool, eraserTool];

    tools.forEach((tool) => {
      if (tool === selectedTool) {
        tool.style.backgroundColor = '#5845FF';
        tool.style.color = 'white';
        tool.style.border = 'none';
      } else {
        tool.style.backgroundColor = 'white';
        tool.style.color = 'black';
        tool.style.border = '2px solid #e5e7eb';
      }
    });
  }

  // Add tools to annotationTools immediately
  annotationTools.appendChild(penTool);
  annotationTools.appendChild(squareTool);
  annotationTools.appendChild(circleTool);
  annotationTools.appendChild(eraserTool);
  annotationTools.appendChild(colorPalette);

  // Append to innerContainer immediately so it's in DOM when updateAnnotationUI runs
  innerContainer.appendChild(annotationTools);

  // Reference functions for clear and save (equivalent to setClearCanvasRef/setSaveAnnotationRef)
  let clearCanvasRef = null;
  let saveAnnotationRef = null;

  // Functions to set references (equivalent to annotation package props)
  const setClearCanvasRef = (clearFn) => {
    clearCanvasRef = clearFn;
  };

  const setSaveAnnotationRef = (saveFn) => {
    saveAnnotationRef = saveFn;
  };

  // Add toggle functionality for annotation tools
  drawingToolButton.addEventListener('click', function () {
    isAnnotationActive = !isAnnotationActive;
    try {
      updateAnnotationUI();
    } catch (error) {
      console.debug('Error updating annotation UI on toggle:', error);
    }

    // Activate or deactivate annotation canvas
    if (isAnnotationActive) {
      activateAnnotationCanvas();

      // Set up reference functions when annotation becomes active
      setClearCanvasRef(clearAnnotationCanvas);
      setSaveAnnotationRef(saveCurrentAnnotation);
    } else {
      deactivateAnnotationCanvas();

      // Clear reference functions when annotation is deactivated
      setClearCanvasRef(null);
      setSaveAnnotationRef(null);
    }

    adjustSize();
  });

  // Screenshot button
  const screenshotButton = document.createElement('button');
  screenshotButton.className = '__injected_main_buttons__';
  screenshotButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"></path>
    <circle cx="12" cy="13" r="4"></circle>
  </svg>`;

  // Add click event for screenshot button
  screenshotButton.addEventListener('click', function () {
    takeScreenshot();
  });

  // Resize/position button
  const resizeButton = document.createElement('button');
  resizeButton.className = '__injected_main_buttons__';

  resizeButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M5 9l4-4 4 4"></path>
    <path d="M5 15l4 4 4-4"></path>
    <path d="M19 9l-4-4-4 4"></path>
    <path d="M19 15l-4 4-4-4"></path>
  </svg>`;
  resizeButton.addEventListener('click', function () {
    adjustSize();
  });

  // Cancel button
  const cancelButton = document.createElement('button');
  cancelButton.className = '__injected_main_buttons__';

  cancelButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#000" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="18" y1="6" x2="6" y2="18"></line>
    <line x1="6" y1="6" x2="18" y2="18"></line>
  </svg>`;

  // Add click event for cancel button
  cancelButton.addEventListener('click', function () {
    // Cancel button: Exit annotation mode completely and clear page
    // No session preview modal should be shown as user decided to cancel

    // If annotation is active, deactivate it without saving
    if (isAnnotationActive) {
      // Deactivate annotation canvas and clear all annotations
      deactivateAnnotationCanvas();
      isAnnotationActive = false;
    }
    // Remove UI and stop all recording processes without saving anything
    removeRecordingUI();

    // Send cancel message to background script
    try {
      chrome.runtime.sendMessage(
        {
          type: 'RECORDING_CANCELLED',
        },
        function (response) {
          if (chrome.runtime.lastError) {
            console.error(
              'Error sending cancel message:',
              chrome.runtime.lastError
            );
          } else {
            console.log('Recording cancelled successfully');
          }
        }
      );
    } catch (error) {
      console.error('Exception sending cancel message:', error);
    }
  });

  // Complete button
  const completeButton = document.createElement('button');
  completeButton.className =
    '__injected_main_buttons__ __complete_session_button__';
  completeButton.innerHTML = `<svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="white" stroke="#4CAF50" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="20 6 9 17 4 12"></polyline>
  </svg>`;

  function isBase64DataURL(str) {
    return typeof str === 'string' && /^data:.*;base64,/.test(str);
  }

  function blobToBase64(blob) {
    return new Promise((resolve, reject) => {
      const reader = new FileReader();
      reader.onloadend = () => resolve(reader.result); // Base64 string
      reader.onerror = reject;
      reader.readAsDataURL(blob);
    });
  }

  // Send session data to background script
  async function sendSessionData({
    metadata,
    audioBlob = null,
    screenshotBlob = null,
    annotationBlob = null,
  }) {
    let audioBase64 = null;
    let screenshotBase64 = null;
    let annotationBase64 = null;
    
    if (audioBlob instanceof Blob && !isAnnotateOnlyMode) {
      audioBase64 = await blobToBase64(audioBlob);
    }

    if (screenshotBlob instanceof Blob) {
      screenshotBase64 = await blobToBase64(screenshotBlob);
    }

    if (annotationBlob instanceof Blob) {
      annotationBase64 = await blobToBase64(annotationBlob);
    }
    chrome.runtime.sendMessage(
      {
        type: 'SAVE_SESSION',
        ID: activeRecordingSessionId,
        data: {
          metadata,
          media: {
            audio: audioBase64,
            audioType: isBase64DataURL(audioBase64) ? audioBlob.type : null,
            audioSize: isBase64DataURL(audioBase64) ? audioBlob.size : 0,
            screenshot: screenshotBase64,
            screenshotType: isBase64DataURL(screenshotBase64)
              ? screenshotBlob.type
              : null,
            screenshotSize: isBase64DataURL(screenshotBase64)
              ? screenshotBlob.size
              : 0,
            annotation: annotationBase64,
            annotationType: isBase64DataURL(annotationBase64)
              ? 'image/png'
              : null,
            annotationSize: isBase64DataURL(annotationBase64)
              ? annotationBlob.size
              : 0,
          },
        },
      },
      function (response) {
        if (chrome.runtime.lastError) {
          console.error('Error saving session:', chrome.runtime.lastError);
        } else if (response.success) {
          console.log('Session saved successfully:', response);
        }
      }
    );
  }

  // Add click event for complete button
completeButton.addEventListener('click', async function () {
    const audioData = {
      hasAudio: !!sessionData.audioBlob,
      duration: recordingDuration,
      chunks: audioChunks.length,
      date: new Date().toISOString(),
    };



function dataURLToBlob(dataUrl) {
  const parts = dataUrl.split(',');
  const mimeMatch = parts[0].match(/:(.*?);/);
  const mimeType = mimeMatch ? mimeMatch[1] : 'application/octet-stream';
  const byteString = atob(parts[1]);
  const arrayBuffer = new ArrayBuffer(byteString.length);
  const uint8Array = new Uint8Array(arrayBuffer);
  for (let i = 0; i < byteString.length; i++) {
    uint8Array[i] = byteString.charCodeAt(i);
  }
  return new Blob([uint8Array], { type: mimeType });
}

const finalizeSession = async () => {
  let annotationBlob = null;

  const hasAnnotationData =
    (isAnnotationActive && annotationCanvasElement?.shapes?.length > 0) ||
    annotationCanvasElement?.lines?.length > 0;

  const shouldAutoScreenshot = !audioOnly && !manualScreenshotTaken && !hasAnnotationData ;

  if (shouldAutoScreenshot && scrollFootprintTracker?.isTracking) {
      const screenshotData = await takeContextAwareScreenshot();
   if (screenshotData?.dataUrl) {
  try {
    screenshotBlob = dataURLToBlob(screenshotData.dataUrl);
    console.log(screenshotBlob);
  } catch (error) {
    console.error("Error converting data URL to Blob:", error);
  }
}



    scrollFootprintTracker.stop();
  }

  if (hasAnnotationData) {
        annotationBlob = await captureLiveAnnotationScreenshot();
    }

  const metadata = {
    title: document.title || 'Untitled Page',
    url: window.location.href,
    timestamp: new Date().toISOString(),
    duration: parseInt(timer.textContent),
    formattedDuration: timer.textContent,
    pageTitle: document.title,
    hasAudio: !!sessionData.audioBlob,
    hasScreenshot: !!screenshotBlob,
    hasAnnotation: !!annotationBlob,
    isAnnotationOnly: !!isAnnotateOnlyMode,
    content: 'No prompt generated yet.',
  };

  await sendSessionData({
    metadata,
    audioBlob: sessionData.audioBlob,
    screenshotBlob,
    annotationBlob,
  });

  chrome.runtime.sendMessage({
    type: 'RECORDING_COMPLETED',
    data: {
      ...audioData,
      timerDisplay: timer.textContent,
    },
  });

  if (annotationBlob) {
    sessionData.annotationBlob = annotationBlob;
  }

  if (isAnnotationActive) {
    deactivateAnnotationCanvas();
    isAnnotationActive = false;
  }

  removeRecordingUI();
};

    if (isRecording && mediaRecorder?.state !== 'inactive') {
      mediaRecorder.stop();
      setTimeout(finalizeSession, 200);
    } else {
      finalizeSession();
    }
  });
if(!annotateOnlyMode) {

  toolsSection.appendChild(tooltipWrapper);
}
  toolsSection.appendChild(drawingToolButton);
  toolsSection.appendChild(screenshotButton);
  toolsSection.appendChild(resizeButton);
  toolsSection.appendChild(cancelButton);
  toolsSection.appendChild(completeButton);

  // Annotation tools section (already created earlier with all tools and handlers)

  // Assemble all sections into the inner container
  innerContainer.appendChild(headerSection);
  innerContainer.appendChild(audioVisualization);
  innerContainer.appendChild(toolsSection);
  // annotationTools already appended earlier

  // Add the inner container to the sidebar
  sidebar.appendChild(innerContainer);

  // Add the sidebar to the page
  document.body.appendChild(sidebar);
  recordingSidebarElement = sidebar;
  adjustSize();
  const DELAY = annotateOnlyMode ? 250 : 1;
  setTimeout(()=> { 
  chrome.runtime.sendMessage(
    {
      type: 'RECORDING_STARTED',
      sessionId: recordingSessionId, // <-- attaching session ID here
    },
    (response) => {
      if (chrome.runtime.lastError) {
        return;
      }
    }
  );
  }, DELAY);
}

// Variables to store session data for preview
let sessionData = {
  audioBlob: null,
  screenshot: null,
  duration: '00:00',
  timestamp: null,
};

// Remove recording UI elements
function removeRecordingUI() {
 

  if (isRecording) {
    stopAudioRecording();
  }
  recordingSidebarActive = false;

  // Remove the recording sidebar if it exists
  if (recordingSidebarElement && recordingSidebarElement.parentNode) {
    recordingSidebarElement.parentNode.removeChild(recordingSidebarElement);
  }

  // Clean up annotation canvas and exit banner if still active
  if (isAnnotationActive) {
    deactivateAnnotationCanvas();
    isAnnotationActive = false;
  }

  if (countdownElement && countdownElement.parentNode) {
    // The parent is the overlay div
    const overlay = countdownElement.parentNode;
    if (overlay && overlay.parentNode) {
      overlay.parentNode.removeChild(overlay);
    }
    countdownActive = false;
  }
}

let annotateOnlyMode = false ;

function startRecording(annotateOnly, ID) {
  console.log('Starting recording, annotate only:', annotateOnly);
  annotateOnlyMode = annotateOnly
  // Clear screenshot state to prevent bleed-through from previous sessions
  screenshotBlob = null;
  manualScreenshotTaken = false;
  capturedScreenshots =  {}
  if (debugMode) {
    console.log(
      'Recording started from: ',
      window.location.search.includes('context=sidePanel')
        ? 'Side Panel'
        : document.referrer.includes('popup.html')
        ? 'Popup'
        : 'Other Context'
    );
  }

  // Set the recording mode
  isAnnotateOnlyMode = annotateOnly;

  // Remove any existing recording UI first to ensure we don't have duplicates
  removeRecordingUI();

  // Hide the floating widget during recording
  hideWidget();

  // Start with countdown
  createCountdownOverlay(ID);

  // Return success
  return { success: true };
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'CANCEL_VIA_BACKGROUND') {
    if (isAnnotationActive) {
      // Deactivate annotation canvas and clear all annotations
      deactivateAnnotationCanvas();
      isAnnotationActive = false;
    }
    removeRecordingUI();
    sendResponse({ success: true, message: 'Annotation and UI removed' });
  }
  return true;
});

// Request audio permission and initialize audio recording
async function requestAudioPermission() {

  try {

    audioStream = await navigator.mediaDevices.getUserMedia({ audio: true });
    startAudioRecording();
    hasAudioPermission = true
    return true;
  } catch (error) {
    hasAudioPermission = false

    // Check specific error types
    if (
      // NotAllowedError can mean user denied permission or website policy blocked it
      error.name === 'NotAllowedError' ||
      // Some browsers report Permission Policy violations explicitly
      (error.message && error.message.includes('permissions policy'))
    ) {
      console.log('Audio recording not available: ' + error.message);

      // If this is clearly a permissions policy violation...
      if (error.message && error.message.includes('permissions policy')) {
        // This is a website policy restriction, show different UI state
        console.log(
          'This website blocks microphone access - screenshots only mode'
        );
      } else {
        // This might be a user denial or a policy issue
        console.log('Microphone access was denied');
      }
    } else {
      // Different type of error
      console.error('Error accessing microphone:', error);
    }

    // In all error cases, return false to indicate we couldn't get microphone access
    return false;
  }
}

// Start recording audio from the microphone
function startAudioRecording() {
  if (!audioStream) {
    console.error('Cannot start recording: no audio stream available');
    return;
  }

  // Reset audio chunks array
  audioChunks = [];

  // Create MediaRecorder instance with lower bitrate for efficiency
  const options = {
    audioBitsPerSecond: 24000, // 24kbps for more efficient storage
    mimeType: 'audio/webm;codecs=opus', // Use opus codec for better compression
  };

  try {
    mediaRecorder = new MediaRecorder(audioStream, options);
  } catch (e) {
    // Fallback to default options if the specified options aren't supported
    console.debug(
      'MediaRecorder with specified options not supported, using defaults:',
      e
    );
    mediaRecorder = new MediaRecorder(audioStream);
  }

  // Handle data available event (when audio chunks are ready)
  mediaRecorder.ondataavailable = (event) => {
    if (event.data.size > 0) {
      audioChunks.push(event.data);
    }
  };

  // Handle recording stop event
  mediaRecorder.onstop = () => {
    // Create a Blob from the audio chunks
    const audioBlob = new Blob(audioChunks, { type: 'audio/webm' });

    console.log('Audio recording completed, size:', audioBlob.size);

    // Store the audio blob and duration for the session preview
    sessionData.audioBlob = audioBlob;
    sessionData.duration = formatTime(recordingDuration);
    sessionData.timestamp = new Date().toLocaleString();

    // Notify background script about the recording completion
    try {
      chrome.runtime.sendMessage({
        type: 'AUDIO_RECORDING_COMPLETED',
        data: {
          audioBlobSize: audioBlob.size,
          duration: recordingDuration,
        },
      });
    } catch (error) {
      console.error('Error sending audio recording completion message:', error);
    }

    // If we have a screenshot, show the session preview modal
    if (sessionData.screenshot) {
      // Add the session preview styles
      //addSessionPreviewStyles();

      // Log what we're showing in the preview for debugging
      console.log('Showing session preview with (audio complete):', {
        hasAudio: !!sessionData.audioBlob,
        hasScreenshot: !!sessionData.screenshot,
        screenshotLength: sessionData.screenshot
          ? sessionData.screenshot.length
          : 0,
      });

      // Show the session preview modal
      // setTimeout(() => {
      //   showSessionPreviewModal(sessionData);
      // }, 500); // Small delay to ensure everything is ready
    }

    // Clean up
    stopAudioVisualization();
    clearInterval(recordingTimer);
    recordingDuration = 0;
  };

  // Start recording
  mediaRecorder.start(1000); // Get data every second
  isRecording = true;

  // Start recording timer
  recordingStartTime = Date.now();
  recordingTimer = setInterval(updateRecordingTime, 1000);

  // Setup audio visualization
  setupAudioVisualization();

  console.log('Audio recording started');
}

// Setup audio visualization using the Web Audio API
function setupAudioVisualization() {
  if (!audioStream) return;
  // Create audio context
  audioContext = new (window.AudioContext || window.webkitAudioContext)();

  // Create an analyzer node
  audioAnalyser = audioContext.createAnalyser();
  audioAnalyser.fftSize = 128; // Small FFT size provides better performance

  // Connect the audio stream to the analyser
  const source = audioContext.createMediaStreamSource(audioStream);
  source.connect(audioAnalyser);

  updateAudioVisualization();
}

// Update the audio visualization data
function updateAudioVisualization() {
  if (!audioAnalyser) return;

  // Schedule next animation frame
  audioVisualizationAnimationFrame = requestAnimationFrame(
    updateAudioVisualization
  );

  // Get both frequency and time-domain data for better visualization
  const bufferLength = audioAnalyser.frequencyBinCount;
  const freqDataArray = new Uint8Array(bufferLength);
  const timeDataArray = new Uint8Array(bufferLength);

  audioAnalyser.getByteFrequencyData(freqDataArray);
  audioAnalyser.getByteTimeDomainData(timeDataArray);

  // Calculate an average of all frequencies for overall volume
  let sum = 0;
  for (let i = 0; i < bufferLength; i++) {
    sum += freqDataArray[i];
  }
  const average = sum / bufferLength;

  // Calculate RMS (root mean square) from time domain data
  // This gives us a better indication of audio volume
  let rms = 0;
  for (let i = 0; i < bufferLength; i++) {
    // Convert to -1.0 to 1.0 range
    const sample = (timeDataArray[i] - 128) / 128;
    rms += sample * sample;
  }
  rms = Math.sqrt(rms / bufferLength);

  // Use a moving average to smooth out visualization
  // (We do this by keeping a fraction of the previous value)
  for (let i = 0; i < 8; i++) {
    // Keep 30% of previous value for smoothing
    const previousValue = audioVisualizationData[i] * 0.3;

    // Frequency specific processing - divide the frequency range into 8 bands
    // Focus on speech frequency bands (approximately 300Hz to 3.5kHz)
    const startIdx =
      Math.floor(bufferLength * 0.05) + Math.floor(i * (bufferLength * 0.1));
    const endIdx = startIdx + Math.floor(bufferLength * 0.05);

    let bandEnergy = 0;
    for (let j = startIdx; j < endIdx; j++) {
      if (j < bufferLength) {
        bandEnergy += freqDataArray[j] / 255.0;
      }
    }
    bandEnergy /= endIdx - startIdx;

    // Apply amplification based on frequency band
    // Higher amplification for middle frequencies (where speech is)
    let amplificationFactor;
    if (i >= 2 && i <= 5) {
      amplificationFactor = 2.5; // Higher amplification for speech frequencies
    } else {
      amplificationFactor = 2.0; // Lower amplification for other frequencies
    }

    // Combine frequency data with RMS for better response to transients
    const rmsWeight = 0.4; // Weight of RMS in the final calculation
    const freqWeight = 0.6; // Weight of frequency data

    // Compute the new value with amplification
    let newValue =
      (bandEnergy * freqWeight + rms * rmsWeight) * amplificationFactor;

    // Add some natural variation
    // Make bars more reactive based on position (middle bars react more to speech)
    const variationFactor = 0.7 + Math.sin((i / 7) * Math.PI) * 0.3;
    newValue *= variationFactor;

    // Amplify low signals to make visualization more interesting even with quiet audio
    if (newValue < 0.2 && newValue > 0.05) {
      newValue = 0.2 + (newValue - 0.05) * 0.5; // Boost low values
    }

    // Ensure values stay in range
    newValue = Math.min(1.0, Math.max(0.0, newValue));

    // Combine with previous value for smooth animation
    audioVisualizationData[i] = previousValue + newValue * 0.7;
  }

  if (!audioVisualizationAnimationFrame) {
    updateAudioVisualization(); // ← Only calls this ONCE if not already animating
  }
  updateAudioVisualizationUI();
}

// Utility to get the recording sidebar element
function findRecordingSidebar() {
  const byId = document.getElementById('ai-prompt-builder-recording-sidebar');
  if (byId) return byId;

  const fallback = document.querySelector(
    'div[style*="ai-prompt-builder-recording-sidebar"]'
  );
  return fallback || null;
}

// Identify the audio visualization container
function findAudioVisualizationContainer(container) {
  const divs = container.querySelectorAll('div');

  for (const div of divs) {
    if (
      div.children.length >= 8 &&
      div.style.display === 'flex' &&
      div.style.flexDirection === 'column'
    ) {
      return div;
    }
  }

  // Fallback if the first check doesn't work
  for (const div of divs) {
    if (div.children.length === 8) {
      const firstChild = div.children[0];
      if (
        firstChild &&
        firstChild.style.height === '4px' &&
        firstChild.style.width === '30px'
      ) {
        return div;
      }
    }
  }

  return null;
}

// Set bar style based on audio level
function styleBar(bar, level) {
  const BAR_HEIGHT = 4;
  const BAR_WIDTH = 30;

  bar.style.width = `${BAR_WIDTH}px`;
  bar.style.height = `${BAR_HEIGHT}px`;
  bar.style.borderRadius = '2px';
  bar.style.marginBottom = '4px';

  if (level > 0.6) {
    bar.style.backgroundColor = '#3B82F6';
  } else if (level > 0.3) {
    bar.style.backgroundColor = '#60A5FA';
  } else if (level > 0.15) {
    bar.style.backgroundColor = '#93C5FD';
  } else {
    bar.style.backgroundColor = '#E0E0E0';
  }
}

function updateAudioVisualizationUI() {
  try {
    const sidebar = findRecordingSidebar();
    if (!sidebar) return;

    const audioVisualization = findAudioVisualizationContainer(sidebar);
    if (!audioVisualization) return;

    const bars = audioVisualization.children;
    if (bars.length < 8) {
      console.debug('Not enough bars found:', bars.length);
      return;
    }

    for (let i = 0; i < 8; i++) {
      const level = audioVisualizationData[i]; // Assumes this is defined globally
      const bar = bars[7 - i]; // Reverse order: bottom to top
      styleBar(bar, level);
    }
  } catch (error) {
    console.error('Error updating audio visualization UI:', error);
  }
}

// Update the recording time
function updateRecordingTime() {
  if (!isRecording) return;

  // Calculate duration in seconds
  recordingDuration = Math.floor((Date.now() - recordingStartTime) / 1000);

  // Update the timer UI
  updateRecordingTimeUI();
}

// Format time in MM:SS format
function formatTime(seconds) {
  const minutes = Math.floor(seconds / 60);
  const remainingSeconds = seconds % 60;
  return `${minutes.toString().padStart(2, '0')}:${remainingSeconds
    .toString()
    .padStart(2, '0')}`;
}

// Update the recording time display in the UI
function updateRecordingTimeUI() {
  try {
    // Find the sidebar element using the same robust approach as audioVisualization
    let sidebar = document.getElementById(
      'ai-prompt-builder-recording-sidebar'
    );
    if (!sidebar) {
      // Try to find it by attribute/style if not by ID
      const possibleSidebars = document.querySelectorAll(
        'div[style*="ai-prompt-builder-recording-sidebar"]'
      );
      if (possibleSidebars.length > 0) {
        sidebar = possibleSidebars[0];
      } else {
        // If we can't find it, use the stored reference
        sidebar = recordingSidebarElement;
      }
    }

    if (!sidebar) {
      return;
    }

    // Try multiple approaches to find the timer span
    let timerDisplay = null;

    // First look for spans directly
    const allSpans = sidebar.querySelectorAll('span');
    for (const span of allSpans) {
      // Check if this span is a timer (has this format 00:00)
      const text = span.textContent || '';
      if (text.match(/^\d\d:\d\d$/) || text === '00:00') {
        timerDisplay = span;
        break;
      }
    }

    // If we couldn't find the timer by text content, look for it by structure
    if (!timerDisplay) {
      // Look for container with red recording dot above the timer
      const allDivs = sidebar.querySelectorAll('div');
      for (const div of allDivs) {
        if (
          div.style.flexDirection === 'column' &&
          div.style.alignItems === 'center'
        ) {
          // Check if it has a child that is the red dot
          const redDot = div.querySelector(
            'div[style*="background-color: #FF3B30"]'
          );
          if (redDot) {
            // The span in this container should be the timer
            timerDisplay = div.querySelector('span');
            break;
          }
        }
      }
    }

    if (!timerDisplay) {
      return;
    }

    // Format time as mm:ss
    const minutes = Math.floor(recordingDuration / 60);
    const seconds = recordingDuration % 60;
    timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds
      .toString()
      .padStart(2, '0')}`;
  } catch (error) {
    console.error('Error updating timer UI:', error);
  }
}

// Stop the audio visualization
function stopAudioVisualization() {
  // Cancel animation frame if active
  if (audioVisualizationAnimationFrame) {
    cancelAnimationFrame(audioVisualizationAnimationFrame);
    audioVisualizationAnimationFrame = null;
  }

  // Close audio context
  if (audioContext) {
    audioContext
      .close()
      .catch((err) => console.error('Error closing audio context:', err));
    audioContext = null;
  }

  // Reset other variables
  audioAnalyser = null;

  // Reset visualization data
  audioVisualizationData = Array(8).fill(0);
}

// Stop the audio recording
function stopAudioRecording() {
  if (!isRecording || !mediaRecorder) {
    console.debug('No active recording to stop');
    return;
  }

  // Stop the media recorder
  if (mediaRecorder.state !== 'inactive') {
    mediaRecorder.stop();
  }

  // Stop all audio tracks
  if (audioStream) {
    audioStream.getTracks().forEach((track) => track.stop());
    audioStream = null;
  }

  // Clean up
  isRecording = false;
  mediaRecorder = null;

  console.log('Audio recording stopped');
}

/* Initialize when the content script loads NOT NEEDED
(function initialize() {
  console.log("Content script initialized");

  // Add event listener for when the page is fully loaded
  if (document.readyState === "complete") {
    // Document already complete, we can run initialization
    addAnimationStyles();
  } else {
    // Document not ready yet, add listener
    window.addEventListener("load", function () {
      addAnimationStyles();
    });
  }
})();

*/

/**
 * Creates and displays a session preview modal with audio, screenshot, and annotation data
 */
function showSessionPreviewModal(sessionData) {
  // Add styles first to ensure they are available
  addSessionPreviewStyles();

  console.log('Showing session preview modal with data:', {
    hasAudioBlob: !!sessionData.audioBlob,
    hasScreenshotBlob: !!sessionData.screenshotBlob,
    hasAnnotationBlob: !!sessionData.annotationBlob,
    hasAudioUrl: !!sessionData.audioUrl,
    hasScreenshotUrl: !!sessionData.screenshotUrl || !!sessionData.screenshot,
  });

  // Create the overlay
  const overlay = document.createElement('div');
  overlay.className = 'session-preview-overlay';

  // Create the modal container
  const modal = document.createElement('div');
  modal.className = 'session-preview-modal';

  // Close button
  const closeButton = document.createElement('button');
  closeButton.className = 'session-preview-close';
  closeButton.innerHTML = '&times;';
  closeButton.addEventListener('click', () => {
    document.body.removeChild(overlay);
  });

  // Modal header
  const header = document.createElement('div');
  header.className = 'session-preview-header';

  const title = document.createElement('h2');
  title.className = 'session-preview-title';
  title.textContent = 'Session Preview';

  const subtitle = document.createElement('p');
  subtitle.className = 'session-preview-subtitle';
  subtitle.textContent = `Recorded on ${new Date().toLocaleString()}`;

  header.appendChild(title);
  header.appendChild(subtitle);

  // Audio section
  const audioSection = document.createElement('div');
  audioSection.className = 'session-preview-section';

  const audioTitle = document.createElement('h3');
  audioTitle.className = 'session-preview-section-title';
  audioTitle.textContent = 'Audio Recording';

  const audioPlayer = document.createElement('div');
  audioPlayer.className = 'session-audio-player';

  // Create audio element if we have audio data
  const audioElement = document.createElement('audio');
  audioElement.controls = true;
  audioElement.style.width = '100%';

  // Check for various forms of audio data that might be available
  let audioURL = null;
  if (sessionData.audioBlob) {
    // Direct blob reference (from recording flow)
    audioURL = URL.createObjectURL(sessionData.audioBlob);
  } else if (sessionData.audioUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    audioURL = sessionData.audioUrl;
  } else if (sessionData.media && sessionData.media.audio) {
    // Raw blob from IndexedDB
    audioURL = URL.createObjectURL(sessionData.media.audio);
  }

  if (audioURL) {
    audioElement.src = audioURL;
  } else {
    audioElement.disabled = true;
    audioElement.innerHTML = 'No audio recording available';
  }

  const audioInfo = document.createElement('div');
  audioInfo.className = 'session-audio-info';

  const audioDuration = document.createElement('span');
  audioDuration.textContent = `Duration: ${
    sessionData.duration ||
    (sessionData.metadata && sessionData.metadata.duration) ||
    '00:00'
  }`;

  const audioSize = document.createElement('span');
  audioSize.textContent = `File size: ${
    sessionData.audioBlob
      ? formatFileSize(sessionData.audioBlob.size)
      : sessionData.media && sessionData.media.audio
      ? formatFileSize(sessionData.media.audio.size)
      : 'N/A'
  }`;

  audioInfo.appendChild(audioDuration);
  audioInfo.appendChild(audioSize);
  audioPlayer.appendChild(audioElement);
  audioPlayer.appendChild(audioInfo);

  audioSection.appendChild(audioTitle);
  audioSection.appendChild(audioPlayer);

  // Screenshot section
  const screenshotSection = document.createElement('div');
  screenshotSection.className = 'session-preview-section';

  const screenshotTitle = document.createElement('h3');
  screenshotTitle.className = 'session-preview-section-title';
  screenshotTitle.textContent = 'Original Screenshot';

  const screenshotPreview = document.createElement('div');
  screenshotPreview.className = 'session-screenshot-preview';

  // Check for original screenshot data (before annotations)
  let screenshotURL = null;
  if (sessionData.screenshotBlob) {
    // Direct blob reference (from recording flow)
    screenshotURL = URL.createObjectURL(sessionData.screenshotBlob);
  } else if (sessionData.screenshotUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    screenshotURL = sessionData.screenshotUrl;
  } else if (sessionData.screenshot) {
    // Legacy data URL format
    screenshotURL = sessionData.screenshot;
  } else if (sessionData.media && sessionData.media.screenshot) {
    // Raw blob from IndexedDB
    screenshotURL = URL.createObjectURL(sessionData.media.screenshot);
  }

  console.log(
    'Session Preview Modal Screenshot URL:',
    screenshotURL ? 'available' : 'not available'
  );

  if (screenshotURL) {
    const img = document.createElement('img');
    img.className = 'session-screenshot-img';
    img.src = screenshotURL;
    img.alt = 'Original Screenshot';
    img.title = 'Click to view full size';

    // Add error handler
    img.onerror = (error) => {
      console.error('Error loading screenshot image:', error);
      const errorMsg = document.createElement('p');
      errorMsg.textContent = 'Error loading screenshot image';
      errorMsg.style.color = '#ef4444';
      errorMsg.style.padding = '20px';
      screenshotPreview.replaceChild(errorMsg, img);
    };

    // Add load handler
    img.onload = () => {
      console.log('Screenshot loaded successfully');
    };

    // Add click handler to show full-size image
    img.addEventListener('click', () => {
      showFullScreenImage(screenshotURL);
    });

    const screenshotInfo = document.createElement('div');
    screenshotInfo.className = 'session-screenshot-info';
    screenshotInfo.textContent =
      'Original screenshot - Click to view full size';

    screenshotPreview.appendChild(img);
    screenshotPreview.appendChild(screenshotInfo);
  } else {
    const noScreenshot = document.createElement('p');
    noScreenshot.textContent = 'No screenshot available';
    noScreenshot.style.padding = '20px';
    noScreenshot.style.color = '#6b7280';
    screenshotPreview.appendChild(noScreenshot);
  }

  screenshotSection.appendChild(screenshotTitle);
  screenshotSection.appendChild(screenshotPreview);

  // Annotation section (shows composite image with annotations)
  const annotationSection = document.createElement('div');
  annotationSection.className = 'session-preview-section';

  const annotationTitle = document.createElement('h3');
  annotationTitle.className = 'session-preview-section-title';
  annotationTitle.textContent = 'Screenshot with Annotations';

  const annotationPreview = document.createElement('div');
  annotationPreview.className = 'session-annotation-preview';

  // Check for annotation data (composite image with annotations)
  let annotationURL = null;
  if (sessionData.annotationBlob) {
    // Direct blob reference (from recording flow) - composite image
    annotationURL = URL.createObjectURL(sessionData.annotationBlob);
  } else if (sessionData.annotationUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    annotationURL = sessionData.annotationUrl;
  } else if (sessionData.annotation) {
    // Legacy data URL format
    annotationURL = sessionData.annotation;
  } else if (sessionData.media && sessionData.media.annotation) {
    // Raw blob from IndexedDB
    annotationURL = URL.createObjectURL(sessionData.media.annotation);
  }

  console.log(
    'Session Preview Modal Annotation URL:',
    annotationURL ? 'available' : 'not available'
  );

  if (annotationURL) {
    const img = document.createElement('img');
    img.className = 'session-annotation-img';
    img.src = annotationURL;
    img.alt = 'Screenshot with Annotations';
    img.title = 'Click to view full size';

    // Add error handler
    img.onerror = (error) => {
      console.error('Error loading annotation image:', error);
      const errorMsg = document.createElement('p');
      errorMsg.textContent = 'Error loading annotation image';
      errorMsg.style.color = '#ef4444';
      errorMsg.style.padding = '20px';
      annotationPreview.replaceChild(errorMsg, img);
    };

    // Add load handler
    img.onload = () => {
      console.log('Composite annotation image loaded successfully');
    };

    // Add click handler to show full-size image
    img.addEventListener('click', () => {
      showFullScreenImage(annotationURL);
    });

    const annotationInfo = document.createElement('div');
    annotationInfo.className = 'session-annotation-info';
    annotationInfo.textContent =
      'Combined view with annotations - Click to view full size';

    annotationPreview.appendChild(img);
    annotationPreview.appendChild(annotationInfo);
  } else {
    const noAnnotation = document.createElement('p');
    noAnnotation.textContent = 'No annotations made';
    noAnnotation.style.padding = '20px';
    noAnnotation.style.color = '#6b7280';
    annotationPreview.appendChild(noAnnotation);
  }

  annotationSection.appendChild(annotationTitle);
  annotationSection.appendChild(annotationPreview);

  // Footer with button
  const footer = document.createElement('div');
  footer.className = 'session-preview-footer';

  const doneButton = document.createElement('button');
  doneButton.className = 'session-preview-button';
  doneButton.textContent = 'Done';
  doneButton.addEventListener('click', () => {
    document.body.removeChild(overlay);
  });

  footer.appendChild(doneButton);

  // Assemble the modal
  modal.appendChild(closeButton);
  modal.appendChild(header);
  modal.appendChild(audioSection);
  modal.appendChild(screenshotSection);
  modal.appendChild(annotationSection);
  modal.appendChild(footer);

  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

/**
 * Shows a fullscreen view of the screenshot
 */
function showFullScreenImage(imgSrc) {
  const overlay = document.createElement('div');
  overlay.className = 'fullscreen-img-overlay';

  const img = document.createElement('img');
  img.className = 'fullscreen-img';
  img.src = imgSrc;
  img.alt = 'Full Size View';

  const closeButton = document.createElement('button');
  closeButton.className = 'fullscreen-close';
  closeButton.innerHTML = '&times;';
  closeButton.addEventListener('click', () => {
    document.body.removeChild(overlay);
  });

  // Also close when clicking anywhere on the overlay
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
if (document.body.contains(overlay)) {
  document.body.removeChild(overlay);
}

    }
  });

  overlay.appendChild(img);
  overlay.appendChild(closeButton);
  document.body.appendChild(overlay);
}

/**
 * Formats file size in readable format
 */
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Captures a live screenshot of the current viewport including annotations
 */
async function captureLiveAnnotationScreenshot() {
  return new Promise((resolve, reject) => {
    // Send message to background script to capture the visible tab
    chrome.runtime.sendMessage({ type: 'TAKE_SCREENSHOT' }, (response) => {
      if (chrome.runtime.lastError) {
        console.error(
          'Error capturing live annotation screenshot:',
          chrome.runtime.lastError.message
        );
        reject(new Error(chrome.runtime.lastError.message));
        return;
      }

      if (response && response.success && response.screenshot) {
        // Convert data URL to blob
        try {
          const base64Data = response.screenshot.split(',')[1];
          const binaryString = atob(base64Data);
          const bytes = new Uint8Array(binaryString.length);

          for (let i = 0; i < binaryString.length; i++) {
            bytes[i] = binaryString.charCodeAt(i);
          }

          const blob = new Blob([bytes], { type: 'image/png' });
          resolve(blob);
        } catch (error) {
          console.error('Error converting screenshot to blob:', error);
          reject(error);
        }
      } else {
        console.error('Invalid screenshot response:', response);
        reject(new Error('Failed to capture screenshot'));
      }
    });
  });
}

// Add CSS styles needed for the modal
function addSessionPreviewStyles() {
  // Check if styles are already added
  if (document.getElementById('session-preview-styles')) {
    return;
  }
}

/**
 * Session Preview Modal for AI Prompt Builder
 *
 * This temporary feature provides a modal to preview recording session data
 * including audio playback and screenshot viewing capabilities.
 */

/**
 * Creates and displays a session preview modal with audio and screenshot data
 */
function showSessionPreviewModal(sessionData) {
  // Add styles first to ensure they are available
  addSessionPreviewStyles();

  console.log('Showing session preview modal with data:', {
    hasAudioBlob: !!sessionData.audioBlob,
    hasScreenshotBlob: !!sessionData.screenshotBlob,
    hasAudioUrl: !!sessionData.audioUrl,
    hasScreenshotUrl: !!sessionData.screenshotUrl || !!sessionData.screenshot,
  });

  // Create the overlay
  const overlay = document.createElement('div');
  overlay.className = 'session-preview-overlay';

  // Create the modal container
  const modal = document.createElement('div');
  modal.className = 'session-preview-modal';

  // Close button
  const closeButton = document.createElement('button');
  closeButton.className = 'session-preview-close';
  closeButton.innerHTML = '&times;';
 closeButton.addEventListener('click', () => {
  if (overlay && document.body.contains(overlay)) {
    document.body.removeChild(overlay);
  }
});

  // Modal header
  const header = document.createElement('div');
  header.className = 'session-preview-header';

  const title = document.createElement('h2');
  title.className = 'session-preview-title';
  title.textContent = 'Session Preview';

  const subtitle = document.createElement('p');
  subtitle.className = 'session-preview-subtitle';
  subtitle.textContent = `Recorded on ${new Date().toLocaleString()}`;

  header.appendChild(title);
  header.appendChild(subtitle);

  // Audio section
  const audioSection = document.createElement('div');
  audioSection.className = 'session-preview-section';

  const audioTitle = document.createElement('h3');
  audioTitle.className = 'session-preview-section-title';
  audioTitle.textContent = 'Audio Recording';

  const audioPlayer = document.createElement('div');
  audioPlayer.className = 'session-audio-player';

  // Create audio element if we have audio data
  const audioElement = document.createElement('audio');
  audioElement.controls = true;
  audioElement.style.width = '100%';

  // Check for various forms of audio data that might be available
  let audioURL = null;
  if (sessionData.audioBlob) {
    // Direct blob reference (from recording flow)
    audioURL = URL.createObjectURL(sessionData.audioBlob);
  } else if (sessionData.audioUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    audioURL = sessionData.audioUrl;
  } else if (sessionData.media && sessionData.media.audio) {
    // Raw blob from IndexedDB
    audioURL = URL.createObjectURL(sessionData.media.audio);
  }

  if (audioURL) {
    audioElement.src = audioURL;
  } else {
    audioElement.disabled = true;
    audioElement.innerHTML = 'No audio recording available';
  }

  const audioInfo = document.createElement('div');
  audioInfo.className = 'session-audio-info';

  const audioDuration = document.createElement('span');
  audioDuration.textContent = `Duration: ${
    sessionData.duration ||
    (sessionData.metadata && sessionData.metadata.duration) ||
    '00:00'
  }`;

  const audioSize = document.createElement('span');
  audioSize.textContent = `File size: ${
    sessionData.audioBlob
      ? formatFileSize(sessionData.audioBlob.size)
      : sessionData.media && sessionData.media.audio
      ? formatFileSize(sessionData.media.audio.size)
      : 'N/A'
  }`;

  audioInfo.appendChild(audioDuration);
  audioInfo.appendChild(audioSize);
  audioPlayer.appendChild(audioElement);
  audioPlayer.appendChild(audioInfo);

  audioSection.appendChild(audioTitle);
  audioSection.appendChild(audioPlayer);

  // Screenshot section
  const screenshotSection = document.createElement('div');
  screenshotSection.className = 'session-preview-section';

  const screenshotTitle = document.createElement('h3');
  screenshotTitle.className = 'session-preview-section-title';
  screenshotTitle.textContent = 'Screenshot';

  const screenshotPreview = document.createElement('div');
  screenshotPreview.className = 'session-screenshot-preview';

  // Check for various forms of screenshot data that might be available
  let screenshotURL = null;
  if (sessionData.screenshotBlob) {
    // Direct blob reference (from recording flow)
    screenshotURL = URL.createObjectURL(sessionData.screenshotBlob);
  } else if (sessionData.screenshotUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    screenshotURL = sessionData.screenshotUrl;
  } else if (sessionData.screenshot) {
    // Legacy data URL format
    screenshotURL = sessionData.screenshot;
  } else if (sessionData.media && sessionData.media.screenshot) {
    // Raw blob from IndexedDB
    screenshotURL = URL.createObjectURL(sessionData.media.screenshot);
  }

  console.log(
    'Session Preview Modal Screenshot URL:',
    screenshotURL ? 'available' : 'not available'
  );

  if (screenshotURL) {
    const img = document.createElement('img');
    img.className = 'session-screenshot-img';
    img.src = screenshotURL;
    img.alt = 'Page Screenshot';
    img.title = 'Click to view full size';

    // Add error handler to help debug loading issues
    img.onerror = (error) => {
      console.error('Error loading screenshot image:', error);
      // Replace with error message
      const errorMsg = document.createElement('p');
      errorMsg.textContent = 'Error loading screenshot image';
      errorMsg.style.color = '#ef4444';
      errorMsg.style.padding = '20px';
      screenshotPreview.replaceChild(errorMsg, img);
    };

    // Add load handler to confirm successful loading
    img.onload = () => {
      console.log('Screenshot loaded successfully');
    };

    // Add click handler to show full-size image
    img.addEventListener('click', () => {
      showFullScreenImage(screenshotURL);
    });

    const screenshotInfo = document.createElement('div');
    screenshotInfo.className = 'session-screenshot-info';
    screenshotInfo.textContent = 'Click the image to view full size';

    screenshotPreview.appendChild(img);
    screenshotPreview.appendChild(screenshotInfo);
  } else {
    const noScreenshot = document.createElement('p');
    noScreenshot.textContent = 'No screenshot available';
    noScreenshot.style.padding = '20px';
    noScreenshot.style.color = '#6b7280';
    screenshotPreview.appendChild(noScreenshot);
  }

  screenshotSection.appendChild(screenshotTitle);
  screenshotSection.appendChild(screenshotPreview);

  // Annotation section
  const annotationSection = document.createElement('div');
  annotationSection.className = 'session-preview-section';

  const annotationTitle = document.createElement('h3');
  annotationTitle.className = 'session-preview-section-title';
  annotationTitle.textContent = 'Annotations';

  const annotationPreview = document.createElement('div');
  annotationPreview.className = 'session-annotation-preview';

  // Check for various forms of annotation data that might be available
  let annotationURL = null;
  if (sessionData.annotationBlob) {
    // Direct blob reference (from recording flow)
    annotationURL = URL.createObjectURL(sessionData.annotationBlob);
  } else if (sessionData.annotationUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    annotationURL = sessionData.annotationUrl;
  } else if (sessionData.annotation) {
    // Legacy data URL format
    annotationURL = sessionData.annotation;
  } else if (sessionData.media && sessionData.media.annotation) {
    // Raw blob from IndexedDB
    annotationURL = URL.createObjectURL(sessionData.media.annotation);
  }

  console.log(
    'Session Preview Modal Annotation URL:',
    annotationURL ? 'available' : 'not available'
  );

  if (annotationURL) {
    const img = document.createElement('img');
    img.className = 'session-annotation-img';
    img.src = annotationURL;
    img.alt = 'Annotation Layer';
    img.title = 'Click to view full size';

    // Add error handler to help debug loading issues
    img.onerror = (error) => {
      console.error('Error loading annotation image:', error);
      // Replace with error message
      const errorMsg = document.createElement('p');
      errorMsg.textContent = 'Error loading annotation image';
      errorMsg.style.color = '#ef4444';
      errorMsg.style.padding = '20px';
      annotationPreview.replaceChild(errorMsg, img);
    };

    // Add load handler to confirm successful loading
    img.onload = () => {
      console.log('Annotation loaded successfully');
    };

    // Add click handler to show full-size image
    img.addEventListener('click', () => {
      showFullScreenImage(annotationURL);
    });

    const annotationInfo = document.createElement('div');
    annotationInfo.className = 'session-annotation-info';
    annotationInfo.textContent = 'Click the image to view full size';

    annotationPreview.appendChild(img);
    annotationPreview.appendChild(annotationInfo);
  } else {
    const noAnnotation = document.createElement('p');
    noAnnotation.textContent = 'No annotations made';
    noAnnotation.style.padding = '20px';
    noAnnotation.style.color = '#6b7280';
    annotationPreview.appendChild(noAnnotation);
  }

  annotationSection.appendChild(annotationTitle);
  annotationSection.appendChild(annotationPreview);

  // Footer with button
  const footer = document.createElement('div');
  footer.className = 'session-preview-footer';

  const doneButton = document.createElement('button');
  doneButton.className = 'session-preview-button';
  doneButton.textContent = 'Done';
doneButton.addEventListener('click', () => {
  if (overlay && document.body.contains(overlay)) {
    document.body.removeChild(overlay);
  }
});

  footer.appendChild(doneButton);

  // Assemble the modal
  modal.appendChild(closeButton);
  modal.appendChild(header);
  modal.appendChild(audioSection);
  modal.appendChild(screenshotSection);
  modal.appendChild(annotationSection);
  modal.appendChild(footer);

  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

/**
 * Shows a fullscreen view of the screenshot
 */
function showFullScreenImage(imgSrc) {
  const overlay = document.createElement('div');
  overlay.className = 'fullscreen-img-overlay';

  const img = document.createElement('img');
  img.className = 'fullscreen-img';
  img.src = imgSrc;
  img.alt = 'Full Screenshot';

  const closeButton = document.createElement('button');
  closeButton.className = 'fullscreen-close';
  closeButton.innerHTML = '&times;';
closeButton.addEventListener('click', () => {
  if (overlay && document.body.contains(overlay)) {
    document.body.removeChild(overlay);
  }
});
  // Also close when clicking anywhere on the overlay
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay && document.body.contains(overlay)) {
      document.body.removeChild(overlay);
    }
  });


  overlay.appendChild(img);
  overlay.appendChild(closeButton);
  document.body.appendChild(overlay);
}

/**
 * Formats file size in readable format
 */
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

/**
 * Session Preview Modal for AI Prompt Builder
 *
 * This temporary feature provides a modal to preview recording session data
 * including audio playback and screenshot viewing capabilities.
 */

/**
 * Creates and displays a session preview modal with audio and screenshot data
 */
function showSessionPreviewModal(sessionData) {
  // Add styles first to ensure they are available
  addSessionPreviewStyles();

  console.log('Showing session preview modal with data:', {
    hasAudioBlob: !!sessionData.audioBlob,
    hasScreenshotBlob: !!sessionData.screenshotBlob,
    hasAudioUrl: !!sessionData.audioUrl,
    hasScreenshotUrl: !!sessionData.screenshotUrl || !!sessionData.screenshot,
  });

  // Create the overlay
  const overlay = document.createElement('div');
  overlay.className = 'session-preview-overlay';

  // Create the modal container
  const modal = document.createElement('div');
  modal.className = 'session-preview-modal';

  // Close button
  const closeButton = document.createElement('button');
  closeButton.className = 'session-preview-close';
  closeButton.innerHTML = '&times;';
closeButton.addEventListener('click', () => {
  if (overlay && document.body.contains(overlay)) {
    document.body.removeChild(overlay);
  }
});
  // Modal header
  const header = document.createElement('div');
  header.className = 'session-preview-header';

  const title = document.createElement('h2');
  title.className = 'session-preview-title';
  title.textContent = 'Session Preview';

  const subtitle = document.createElement('p');
  subtitle.className = 'session-preview-subtitle';
  subtitle.textContent = `Recorded on ${new Date().toLocaleString()}`;

  header.appendChild(title);
  header.appendChild(subtitle);

  // Audio section
  const audioSection = document.createElement('div');
  audioSection.className = 'session-preview-section';

  const audioTitle = document.createElement('h3');
  audioTitle.className = 'session-preview-section-title';
  audioTitle.textContent = 'Audio Recording';

  const audioPlayer = document.createElement('div');
  audioPlayer.className = 'session-audio-player';

  // Create audio element if we have audio data
  const audioElement = document.createElement('audio');
  audioElement.controls = true;
  audioElement.style.width = '100%';

  // Check for various forms of audio data that might be available
  let audioURL = null;
  if (sessionData.audioBlob) {
    // Direct blob reference (from recording flow)
    audioURL = URL.createObjectURL(sessionData.audioBlob);
  } else if (sessionData.audioUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    audioURL = sessionData.audioUrl;
  } else if (sessionData.media && sessionData.media.audio) {
    // Raw blob from IndexedDB
    audioURL = URL.createObjectURL(sessionData.media.audio);
  }

  if (audioURL) {
    audioElement.src = audioURL;
  } else {
    audioElement.disabled = true;
    audioElement.innerHTML = 'No audio recording available';
  }

  const audioInfo = document.createElement('div');
  audioInfo.className = 'session-audio-info';

  const audioDuration = document.createElement('span');
  audioDuration.textContent = `Duration: ${
    sessionData.duration ||
    (sessionData.metadata && sessionData.metadata.duration) ||
    '00:00'
  }`;

  const audioSize = document.createElement('span');
  audioSize.textContent = `File size: ${
    sessionData.audioBlob
      ? formatFileSize(sessionData.audioBlob.size)
      : sessionData.media && sessionData.media.audio
      ? formatFileSize(sessionData.media.audio.size)
      : 'N/A'
  }`;

  audioInfo.appendChild(audioDuration);
  audioInfo.appendChild(audioSize);
  audioPlayer.appendChild(audioElement);
  audioPlayer.appendChild(audioInfo);

  audioSection.appendChild(audioTitle);
  audioSection.appendChild(audioPlayer);

  // Screenshot section
  const screenshotSection = document.createElement('div');
  screenshotSection.className = 'session-preview-section';

  const screenshotTitle = document.createElement('h3');
  screenshotTitle.className = 'session-preview-section-title';
  screenshotTitle.textContent = 'Screenshot';

  const screenshotPreview = document.createElement('div');
  screenshotPreview.className = 'session-screenshot-preview';

  // Check for various forms of screenshot data that might be available
  let screenshotURL = null;
  if (sessionData.screenshotBlob) {
    // Direct blob reference (from recording flow)
    screenshotURL = URL.createObjectURL(sessionData.screenshotBlob);
  } else if (sessionData.screenshotUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    screenshotURL = sessionData.screenshotUrl;
  } else if (sessionData.screenshot) {
    // Legacy data URL format
    screenshotURL = sessionData.screenshot;
  } else if (sessionData.media && sessionData.media.screenshot) {
    // Raw blob from IndexedDB
    screenshotURL = URL.createObjectURL(sessionData.media.screenshot);
  }

  console.log(
    'Session Preview Modal Screenshot URL:',
    screenshotURL ? 'available' : 'not available'
  );

  if (screenshotURL) {
    const img = document.createElement('img');
    img.className = 'session-screenshot-img';
    img.src = screenshotURL;
    img.alt = 'Page Screenshot';
    img.title = 'Click to view full size';

    // Add error handler to help debug loading issues
    img.onerror = (error) => {
      console.error('Error loading screenshot image:', error);
      // Replace with error message
      const errorMsg = document.createElement('p');
      errorMsg.textContent = 'Error loading screenshot image';
      errorMsg.style.color = '#ef4444';
      errorMsg.style.padding = '20px';
      screenshotPreview.replaceChild(errorMsg, img);
    };

    // Add load handler to confirm successful loading
    img.onload = () => {
      console.log('Screenshot loaded successfully');
    };

    // Add click handler to show full-size image
    img.addEventListener('click', () => {
      showFullScreenImage(screenshotURL);
    });

    const screenshotInfo = document.createElement('div');
    screenshotInfo.className = 'session-screenshot-info';
    screenshotInfo.textContent = 'Click the image to view full size';

    screenshotPreview.appendChild(img);
    screenshotPreview.appendChild(screenshotInfo);
  } else {
    const noScreenshot = document.createElement('p');
    noScreenshot.textContent = 'No screenshot available';
    noScreenshot.style.padding = '20px';
    noScreenshot.style.color = '#6b7280';
    screenshotPreview.appendChild(noScreenshot);
  }

  screenshotSection.appendChild(screenshotTitle);
  screenshotSection.appendChild(screenshotPreview);

  // Annotation section
  const annotationSection = document.createElement('div');
  annotationSection.className = 'session-preview-section';

  const annotationTitle = document.createElement('h3');
  annotationTitle.className = 'session-preview-section-title';
  annotationTitle.textContent = 'Annotations';

  const annotationPreview = document.createElement('div');
  annotationPreview.className = 'session-annotation-preview';

  // Check for various forms of annotation data that might be available
  let annotationURL = null;
  if (sessionData.annotationBlob) {
    // Direct blob reference (from recording flow)
    annotationURL = URL.createObjectURL(sessionData.annotationBlob);
  } else if (sessionData.annotationUrl) {
    // Pre-created object URL (from IndexedDB via background script)
    annotationURL = sessionData.annotationUrl;
  } else if (sessionData.annotation) {
    // Legacy data URL format
    annotationURL = sessionData.annotation;
  } else if (sessionData.media && sessionData.media.annotation) {
    // Raw blob from IndexedDB
    annotationURL = URL.createObjectURL(sessionData.media.annotation);
  }

  console.log(
    'Session Preview Modal Annotation URL:',
    annotationURL ? 'available' : 'not available'
  );

  if (annotationURL) {
    const img = document.createElement('img');
    img.className = 'session-annotation-img';
    img.src = annotationURL;
    img.alt = 'Annotation Layer';
    img.title = 'Click to view full size';

    // Add error handler to help debug loading issues
    img.onerror = (error) => {
      console.error('Error loading annotation image:', error);
      // Replace with error message
      const errorMsg = document.createElement('p');
      errorMsg.textContent = 'Error loading annotation image';
      errorMsg.style.color = '#ef4444';
      errorMsg.style.padding = '20px';
      annotationPreview.replaceChild(errorMsg, img);
    };

    // Add load handler to confirm successful loading
    img.onload = () => {
      console.log('Annotation loaded successfully');
    };

    // Add click handler to show full-size image
    img.addEventListener('click', () => {
      showFullScreenImage(annotationURL);
    });

    const annotationInfo = document.createElement('div');
    annotationInfo.className = 'session-annotation-info';
    annotationInfo.textContent = 'Click the image to view full size';

    annotationPreview.appendChild(img);
    annotationPreview.appendChild(annotationInfo);
  } else {
    const noAnnotation = document.createElement('p');
    noAnnotation.textContent = 'No annotations made';
    noAnnotation.style.padding = '20px';
    noAnnotation.style.color = '#6b7280';
    annotationPreview.appendChild(noAnnotation);
  }

  annotationSection.appendChild(annotationTitle);
  annotationSection.appendChild(annotationPreview);

  // Footer with button
  const footer = document.createElement('div');
  footer.className = 'session-preview-footer';

  const doneButton = document.createElement('button');
  doneButton.className = 'session-preview-button';
  doneButton.textContent = 'Done';
doneButton.addEventListener('click', () => {
  if (overlay && document.body.contains(overlay)) {
    document.body.removeChild(overlay);
  }
});

  footer.appendChild(doneButton);

  // Assemble the modal
  modal.appendChild(closeButton);
  modal.appendChild(header);
  modal.appendChild(audioSection);
  modal.appendChild(screenshotSection);
  modal.appendChild(annotationSection);
  modal.appendChild(footer);

  overlay.appendChild(modal);
  document.body.appendChild(overlay);
}

/**
 * Shows a fullscreen view of the screenshot
 */
function showFullScreenImage(imgSrc) {
  const overlay = document.createElement('div');
  overlay.className = 'fullscreen-img-overlay';

  const img = document.createElement('img');
  img.className = 'fullscreen-img';
  img.src = imgSrc;
  img.alt = 'Full Screenshot';

  const closeButton = document.createElement('button');
  closeButton.className = 'fullscreen-close';
  closeButton.innerHTML = '&times;';
closeButton.addEventListener('click', () => {
  if (overlay && document.body.contains(overlay)) {
    document.body.removeChild(overlay);
  }
});
  // Also close when clicking anywhere on the overlay
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay  && document.body.contains(overlay)) {
      document.body.removeChild(overlay);
    }
  });

  overlay.appendChild(img);
  overlay.appendChild(closeButton);
  document.body.appendChild(overlay);
}

/**
 * Formats file size in readable format
 */
function formatFileSize(bytes) {
  if (bytes === 0) return '0 Bytes';

  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));

  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

function adjustSize(selector = '#ai-prompt-builder-recording-sidebar') {
  const sidebar = document.querySelector(selector);
  if (!sidebar) return;

  const viewportHeight = window.innerHeight;
  const sidebarHeight = sidebar.scrollHeight;

  if (sidebarHeight > viewportHeight) {
    const zoomRatio = viewportHeight / sidebarHeight;
    sidebar.style.zoom = zoomRatio;
  } else {
    sidebar.style.zoom = '';
  }
}

window.addEventListener('resize', () => adjustSize());


