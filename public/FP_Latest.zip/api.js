// config.js
const API_HOST = "https://frankly-prompt-web-appstep-0-reginald9.replit.app/api";
const DOC_KEY = "fB2v-Z9nT-qY74-Jk8p-UDx1-mEqaCvzQhK9V";

// utils.js
async function getStoredApiKey() {
  return new Promise((resolve) => {
    chrome.storage.local.get(["licenseKey"], (result) => {
      resolve(result?.licenseKey || null);
    });
  });
}

async function fetchWithKey(endpoint, options = {}) {
  try {
    const apiKey = await getStoredApiKey();  
    if (!apiKey) {
      throw new Error("A license key is required. Please configure your license key in the Settings tab.");
    }

    const headers = {
      Accept: "application/json",
      ...options.headers,
      "X-API-Key": apiKey,
      "X-Docs-Key": DOC_KEY
    };

    const response = await fetch(`${API_HOST}${endpoint}`, {
      ...options,
      headers,
    });

    if (!response.ok) {
        throw new Error("Error fetching key usage stats. Please try again later.");
    }
    return response;
  } catch (error) {
      throw new Error("Error fetching key usage stats. Please try again later.");
  }
}



export async function getKeyUsageStats() {
  try {
    const res = await fetchWithKey("/key-usage-stats");
    const data = await res.json();
    console.log(data)
    if (!res.ok) throw new Error("Error fetching key usage stats. Please try again later.");

    return { success: true, data: data.data };
  } catch (error) {
    return { success: false, error: error.message };
  }
}

export async function startRecordingSession(userId, userAgent) {
  try {
    const res = await fetchWithKey(
      "/start-recording-session",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, userAgent }),
      }
    );
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Start session failed");

    return {
      success: true,
      sessionId: data.sessionId,
      status: data.status,
      message: data.message,
    };
  } catch (error) {
    throw new Error("Please try again few minutes later.");
  }
}


export async function startAnnotationSession(userId, userAgent) {
  try {
    const res = await fetchWithKey(
      "/annotation-session/start",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, userAgent }),
      }
    );
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Start session failed");

    return {
      success: true,
      sessionId: data.sessionId,
      status: data.status,
      message: data.message,
    };
  } catch (error) {
    throw new Error("Please try again few minutes later.");
  }
}

export async function completeAnnotationSession(sessionId) {
  try {
    const res = await fetchWithKey(`/annotation-session/complete`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ sessionId }),
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Complete session failed");

    return {
      success: true,
      message: data.message,
    };
  } catch (error) {
    console.error("Complete Session Error:", error.message);
    return { success: false, error: error.message };
  }
}


export async function completeRecordingSession(sessionId) {
  try {
    const res = await fetchWithKey(`/session/${sessionId}/complete`, { method: "POST" });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Complete session failed");

    return {
      success: true,
      message: data.message,
      sessionId: data.sessionId,
      status: data.status,
      orchestrationResult: data.orchestrationResult,
    };
  } catch (error) {
    console.error("Complete Session Error:", error.message);
    return { success: false, error: error.message };
  }
}

export async function uploadSessionMedia({
  base64Data,
  mediaType,
  sessionId,
  fileType = "image/png",
  fileName = "upload.png", 
}) {
  try {
    const byteCharacters = atob(base64Data.split(",")[1]);
    const byteNumbers = Array.from(byteCharacters, (char) => char.charCodeAt(0));
    const byteArray = new Uint8Array(byteNumbers);
    const blob = new Blob([byteArray], { type: fileType });

    const formData = new FormData();
    formData.append("file", blob, fileName);
    formData.append("mediaType", mediaType);
    formData.append("sessionId", sessionId);

    const res = await fetchWithKey("/upload-session-media", {
      method: "POST",
      body: formData,
    });

    const data = await res.json();

    if (!res.ok) throw new Error(data.message || "Upload failed");

    return { success: true, ...data };
  } catch (error) {
    console.error("Upload Media Error:", error.message);
    return { success: false, error: error.message };
  }
}

export async function validateApiKey(apiKey) {
  try {
    const res = await fetch(`${API_HOST}/validate-api-key?`, {
      headers: {
        Accept: "application/json",
        "X-API-Key": apiKey,
        'X-Docs-Key': DOC_KEY
      },
    });

    const data = await res.json();
    if (!res.ok) throw new Error(data.message || "Invalid API key");
    return { success: true, data: data.data };
  } catch (error) {
    console.error("API Key Validation Error:", error.message);
    return { success: false, error: error.message };
  }
}


export async function getProcessResult(sessionId) {
  try {
    const res = await fetchWithKey(
      "/orchestrate-session",
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ sessionId }),
      }
    );
    const data = await res.json();

    if (!res.ok) throw new Error(data.message || "Start session failed");

    return {
      success: true,
      finalPrompt: data.finalPrompt,
      sessionId: data.sessionId,
      status: data.status,
    };
  } catch (error) {
    console.error("Start Recording Session Error:", error.message);
    return { success: false, error: error.message };
  }
}
