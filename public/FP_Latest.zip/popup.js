chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const handlers = {
    CLOSE_POPUP: () => handleClosePopup(sendResponse),
  };

  if (handlers[message.type]) {
    handlers[message.type]();
    return true;
  }
});



function handleClosePopup(sendResponse) {
  try {
    window.close()
    sendResponse({ success: true });
  } catch (error) {
    sendResponse({ success: false, error: error.message });
  }
}


